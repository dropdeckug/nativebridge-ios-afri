const cron = require("node-cron");

const sendReEngagementEmails =
  require("../services/reEngagementService");

// runs every hour
cron.schedule("0 * * * *", async () => {

  console.log(
    "Running re-engagement system..."
  );

  await sendReEngagementEmails();

});
