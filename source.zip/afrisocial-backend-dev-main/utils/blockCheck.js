const User = require("../models/User");

/**
 * Returns true when either userA has blocked userB
 * or userB has blocked userA.
 */
async function isBlocked(userAId, userBId) {
  if (!userAId || !userBId) return false;
  const a = userAId.toString();
  const b = userBId.toString();

  const [me, them] = await Promise.all([
    User.findById(a).select("blockedUsers"),
    User.findById(b).select("blockedUsers"),
  ]);

  const meBlocks   = (me?.blockedUsers   || []).map(x => x.toString());
  const themBlocks = (them?.blockedUsers || []).map(x => x.toString());

  return meBlocks.includes(b) || themBlocks.includes(a);
}

module.exports = { isBlocked };
