// utils/sendEmail.js

const { Resend } = require("resend");

const resend =
  new Resend(
    process.env.RESEND_API_KEY
  );

module.exports = async function sendEmail({

  to,

  subject,

  html

}) {

  try {

    const data =
      await resend.emails.send({

        from:
          "Afrisocial <noreply@afrisocial.com.ng>",

        to,

        subject,

        html

      });

    return data;

  } catch (err) {

    console.error(
      "RESEND ERROR:",
      err
    );

    throw new Error(
      "Email sending failed"
    );

  }

};
