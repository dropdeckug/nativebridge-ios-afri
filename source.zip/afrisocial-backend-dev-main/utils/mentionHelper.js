const User = require("../models/User");
const Notification = require("../models/Notification");
const { sendPushNotification } = require("../controllers/notificationController");

/**
 * Extracts usernames starting with @ and sends notifications.
 * Also returns valid mentioned user IDs.
 * 
 * @param {string} text
 * @param {string} senderId
 * @param {string} type - "post", "comment", or "message"
 * @param {string} referenceId
 */
exports.handleMentions = async (text, senderId, type, referenceId) => {
  try {
    //  Always return array (prevents undefined bugs)
    if (!text) return [];

    const mentionRegex = /@(\w+)/g;
    const matches = [...text.matchAll(mentionRegex)];

    if (matches.length === 0) return [];

    //  Unique usernames (lowercase safe)
    const usernames = [
      ...new Set(matches.map(m => m[1].toLowerCase()))
    ];

    //  Fetch mentioned users
    const mentionedUsers = await User.find({
      username: { $in: usernames }
    }).select("_id blockedUsers");

    // Fetch sender
    const sender = await User.findById(senderId)
      .select("username fullName profilePicture blockedUsers");

    if (!sender) return [];

    // Process mentions safely
    const results = await Promise.all(
      mentionedUsers.map(async (user) => {
        //  Skip self mention
        if (user._id.toString() === senderId.toString()) return null;

        // Block check (SAFE ObjectId comparison)
        const isBlocked =
          user.blockedUsers?.some(id => id.toString() === senderId.toString()) ||
          sender.blockedUsers?.some(id => id.toString() === user._id.toString());

        if (isBlocked) return null;

        // Create notification
        await Notification.create({
          recipient: user._id,
          sender: senderId,
          type: "mention",
          content: `mentioned you in a ${type}`,
          [type]: referenceId,
        });

        // Push notification
        const payload = {
          title: "New Mention",
          body: `${sender.username} mentioned you in a ${type}`,
          icon: sender.profilePicture || "/uploads/images/africa.png",
          data: { url: `/view-post.html?id=${referenceId}` }
        };

        await sendPushNotification(user._id, payload);

        // Return valid ID
        return user._id;
      })
    );

    // Remove nulls + duplicates
    const validIds = [...new Set(results.filter(Boolean).map(id => id.toString()))];

    return validIds;

  } catch (err) {
    console.error("MENTION HELPER ERROR:", err);
    return []; 
  }
};
