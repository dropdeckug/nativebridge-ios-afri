const admin = require("../config/firebase");
const Notification = require("../models/Notification");
const User = require("../models/User");


// Get all notifications for current user
exports.getNotifications = async (req, res) => {
  try {
    const notifications = await Notification.find({ 
      recipient: req.user._id,
      type: { $nin: ["message"] } // Exclude message notifications
    })
      .populate("sender", "fullName profilePicture country isVerified")
      .populate("post", "_id")
      .populate("comment", "_id")
      .sort({ createdAt: -1 });

    res.status(200).json(notifications);
  } catch (err) {
    console.error("Failed to fetch notifications:", err);
    res.status(500).json({ message: "Failed to fetch notifications" });
  }
};

// Mark a notification as read
exports.markAllAsRead = async (req, res) => {
  try {
    await Notification.updateMany(
      { recipient: req.user, isRead: false },
      { $set: { isRead: true } }
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: "Failed to mark notifications as read" });
  }
};

// GET UNREAD NOTIFICATION COUNT
exports.getUnreadCount = async (req, res) => {
  try {
    const count = await Notification.countDocuments({
      recipient: req.user,
      isRead: false
    });

    res.json({ count });
  } catch (err) {
    res.status(500).json({ message: "Failed to load unread count" });
  }

};


// GET NOTIFICATION SUBSCRIPTIONS
exports.saveSubscription = async (req, res) => {
  try {
    const { token } = req.body;

    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.fcmToken = token;
    await user.save();

    res.json({ message: "FCM token saved successfully" });

  } catch (err) {
    console.error("FCM token error:", err);
    res.status(500).json({ message: "Failed to save FCM token" });
  }
};


// Send a push notification to a specific user
exports.sendPushNotification = async (userId, payload) => {
  try {
    const user = await User.findById(userId);

    if (!user || !user.fcmToken) return;

    const message = {
      token: user.fcmToken,
      notification: {
        title: payload.title || "Afrisocial",
        body: payload.body || "You have a new notification 🔔"
      }
    };

    await admin.messaging().send(message);

    console.log("Notification sent successfully");
  } catch (err) {
    console.error("FCM notification error:", err);
  }
};





