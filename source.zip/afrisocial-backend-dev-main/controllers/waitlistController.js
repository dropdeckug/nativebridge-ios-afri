const Waitlist = require("../models/Waitlist");

exports.joinWaitlist = async (req, res) => {
  try {
    const { name, email, country } = req.body;

    if (!name || !email) {
      return res.status(400).json({
        message: "Name and email are required"
      });
    }

    // Check if already exists
    const existing = await Waitlist.findOne({ email });

    if (existing) {
      return res.status(200).json({
        message: "You are already on the waitlist"
      });
    }

    const newUser = await Waitlist.create({
      name,
      email,
      country
    });

    res.status(201).json({
      message: "Successfully joined waitlist",
      data: newUser
    });

  } catch (error) {
    console.error("Waitlist error:", error);
    res.status(500).json({
      message: "Server error"
    });
  }
};
