const Feedback = require("../models/Feedback");

// Create feedback
exports.createFeedback = async (req, res) => {
  try {
    const { type, message } = req.body;

    if (!type || !message) {
      return res.status(400).json({ message: "Type and message are required" });
    }

    const feedback = await Feedback.create({
      user: req.user._id,
      type,
      message,
    });

    res.status(201).json({ message: "Feedback submitted successfully", feedback });
  } catch (err) {
    console.error("Error creating feedback:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all feedback (admin only)
exports.getAllFeedback = async (req, res) => {
  try {
    const feedbacks = await Feedback.find().populate("user", "fullName email");
    res.status(200).json(feedbacks);
  } catch (err) {
    console.error("Error fetching feedback:", err);
    res.status(500).json({ message: "Server error" });
  }
};
