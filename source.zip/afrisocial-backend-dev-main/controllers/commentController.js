const Comment = require("../models/Comment");
const Notification = require("../models/Notification");
const Post = require("../models/Post");
const User = require("../models/User");
const { sendPushNotification } = require("./notificationController");
const { logActivity } = require("./userActivityController");
const { handleMentions } = require("../utils/mentionHelper");
const activateReferral = require("../utils/activateReferral");
const updateFeedPreferences = require("../utils/updateFeedPreferences");



// CREATE COMMENT
exports.createComment = async (req, res) => {
  try {
    const comment = await Comment.create({
      post: req.params.postId,
      user: req.user.id,
      text: req.body.text
    });

    // HANDLE MENTIONS 
    const mentions = await handleMentions(
      req.body.text,
      req.user.id,
      "comment",
      comment._id
    );

    comment.mentions = mentions;
    await comment.save();

    // INCREMENT COMMENT COUNT
     await Post.findByIdAndUpdate(
     req.params.postId,
     {
      $inc: {
      commentCount: 1
    }
  }
);

    // POPULATE (IMPORTANT FOR FRONTEND)
    await comment.populate("user", "username fullName profilePicture country isVerified");
    await comment.populate("mentions", "username fullName profilePicture");

    // GET POST FIRST 
    const post = await Post.findById(req.params.postId);

    
    // UPDATE FEED PREFERENCE 
    await updateFeedPreferences(
    req.user.id,
   post.hashtags,
   4
  );
    
    // LOG ACTIVITY
    await logActivity(req.user.id, "comment", comment._id);

 // Increase total comments
await User.findByIdAndUpdate(
  req.user.id,
  {
    $inc: {
      totalComments: 1
    }
  }
);

// Check referral activation
await activateReferral(
  req.user.id
);

    // NORMAL COMMENT NOTIFICATION

    if (post.user.toString() !== req.user.toString()) {
      await Notification.create({
        recipient: post.user,
        sender: req.user,
        type: "comment",
        post: post._id,
        comment: comment._id
      });

      const sender = await User.findById(req.user.id);

      const payload = {
        title: "New Comment",
        body: `${sender.fullName} commented 💬 on your post`,
        icon:  sender.profilePicture,
        click_action: "/notification.html"
      };

      await sendPushNotification(post.user, payload);
    }

    res.status(201).json(comment);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};




// GET COMMENTS FOR A POST
exports.getPostComments = async (req, res) => {
  try {
    const comments = await Comment.find({
      post: req.params.postId
    })
      .populate("user", "username fullName profilePicture country  isVerified")
      .populate("mentions", "username fullName profilePicture")
      .sort({

         isGift: -1,

         giftStars: -1,

         createdAt: -1

    });
    res.json(comments);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};





// LIKE / UNLIKE COMMENT
exports.likeComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.commentId);
    if (!comment) return res.status(404).json({ message: "Comment not found" });

    const userId = req.user.id; 
    const index = comment.likes.indexOf(userId);
    if (index === -1) {
      comment.likes.push(userId);
      // LOG COMMENT LIKE
  await logActivity(userId, "like_comment", comment._id);
      
    } else {
      comment.likes.splice(index, 1);
    }
    await comment.save();
    res.json({
      likes: comment.likes,
      liked: index === -1
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};


// REPLY TO COMMENT
exports.replyComment = async (req, res) => {
  try {
    const { text } = req.body;

    const parentComment = await Comment.findById(req.params.commentId);
    if (!parentComment) {
      return res.status(404).json({ message: "Parent comment not found" });
    }

    const reply = await Comment.create({
      post: parentComment.post,
      user: req.user.id,
      text,
      parentComment: parentComment._id
    });

    // HANDLE MENTIONS
    const mentions = await handleMentions(
      text,
      req.user.id,
      "reply",
      reply._id
    );

    reply.mentions = mentions;
    await reply.save();

    // LOG
    await logActivity(req.user.id, "reply", reply._id);

    // POPULATE (IMPORTANT)
    await reply.populate("user", "username fullName profilePicture country isVerified");
    await reply.populate("mentions", "username fullName profilePicture");

    // NOTIFICATION (reply owner)
    if (parentComment.user.toString() !== req.user.id) {
      await Notification.create({
        recipient: parentComment.user,
        sender: req.user.id,
        type: "reply",
        post: parentComment.post,
        comment: parentComment._id
      });

      const sender = await User.findById(req.user.id);

      const payload = {
        title: "New Reply",
        body: `${sender.fullName} replied 🗨️ to your comment`,
        icon:  sender.profilePicture,
        click_action: "/notification.html"
      };

      await sendPushNotification(parentComment.user, payload);
    }

    res.status(201).json(reply);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};



// Get all comments for a post
exports.getCommentsByPost = async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId })
      .populate("user", "fullName profilePicture country isVerified")
      .sort({

        isGift: -1,

        giftStars: -1,

        createdAt: -1

     });

    //  fetch nested replies 
    const commentsWithReplies = await Promise.all(
      comments.map(async comment => {
        let replies = [];
        if (comment.replies && comment.replies.length > 0) {
          replies = await Comment.find({ _id: { $in: comment.replies } })
            .populate("user", "fullName profilePicture country isVerified")
           .populate("mentions", "username fullName profilePicture") 
            .sort({ createdAt: 1 });
        }
        return { ...comment.toObject(), replies };
      })
    );

    res.json(commentsWithReplies);
  } catch (err) {
    console.error("GET COMMENTS ERROR:", err);
    res.status(500).json({ message: "Failed to fetch comments" });
  }
};
