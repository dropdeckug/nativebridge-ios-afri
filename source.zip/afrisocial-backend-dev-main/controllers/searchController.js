const User = require("../models/User");
const Post = require("../models/Post");

exports.search = async (req, res) => {
  try {
    const q = req.query.q?.trim();
    const userId = req.user?._id;

    if (!q) {
      return res.json({ results: [] });
    }

    const searchRegex = new RegExp(q, "i");

    // RUN ALL QUERIES IN PARALLEL
    const [users, posts, videos, hashtagPosts] = await Promise.all([

      // USERS — uses text index
      User.find(
        { $text: { $search: q } },
        { score: { $meta: "textScore" } }
      )
      .select("username fullName profilePicture country isVerified")
      .sort({ score: { $meta: "textScore" } })
      .limit(20),

      // POSTS — uses text index
      Post.find(
        { $text: { $search: q } },
        { score: { $meta: "textScore" } }
      )
      .populate("user", "username fullName profilePicture country isVerified")
      .populate("mentions", "username fullName profilePicture")
      .sort({ score: { $meta: "textScore" } })
      .limit(40),

      // VIDEOS — regex on video posts (text index may miss videos with no text)
      Post.find({
        video: { $exists: true, $ne: null },
        $or: [
          { text: searchRegex },
          { hashtags: searchRegex }

        ]
      })
      .populate("user", "username fullName profilePicture")
      .populate("mentions", "username fullName profilePicture")
      .limit(20),

      // HASHTAGS — uses text index
      Post.find(
        { $text: { $search: q } }
      )
      .select("hashtags")
      .limit(200)

    ]);

    const results = [];
    const seenIds = new Set();

    // USERS
    users.forEach(user => {
      results.push({
        type: "people",
        _id: user._id,
        username: user.username,
        fullName: user.fullName,
        profilePicture: user.profilePicture,
        country: user.country,
        isVerified: user.isVerified
      });
    });

    // POSTS
    posts.forEach(post => {
  const id = String(post._id);
  if (seenIds.has(id)) return;
  seenIds.add(id);

  const score =
    (post.views || 0) +
    (post.likes?.length || 0) * 5 +
    (post.stars?.length || 0) * 8 +
    (post.comments?.length || 0) * 4;

  const isVideo = !!post.video;

  // Post tab
  results.push({
    type: "post",
    score,
    _id: post._id,
    text: post.text,
    image: post.images?.[0] || null,
    images: post.images || [],
    video: post.video || null,
    videoThumbnail: post.videoThumbnail || null,
    thumbnail: post.videoThumbnail || null,
    likes: post.likes || [],
    stars: post.stars || [],
    commentCount: post.comments?.length || 0,
    author: {
      username: post.user?.username,
      fullName: post.user?.fullName,
      country: post.user?.country,
      isVerified: post.user?.isVerified,
      profilePicture: post.user?.profilePicture
    }
  });

  // Videos tab
  if (isVideo) {
    results.push({
      type: "videos",
      score,
      _id: post._id,
      video: post.video,
      thumbnail: post.videoThumbnail || null,
      author: {
        username: post.user?.username,
        profilePicture: post.user?.profilePicture
      }
    });
  }

});


    // VIDEOS (deduplicated)
    videos.forEach(video => {
      const id = String(video._id);
      if (seenIds.has(id)) return;
      seenIds.add(id);

      const score =
        (video.views || 0) +
        (video.likes?.length || 0) * 5 +
        (video.stars?.length || 0) * 8 +
        (video.comments?.length || 0) * 4;

      results.push({
        type: "videos",
        score,
        _id: video._id,
        text: video.text,
        image: video.images?.[0] || null,
        images: video.images || [],
        video: video.video,
        videoThumbnail: video.videoThumbnail || null,
        thumbnail: video.videoThumbnail || null,
        likes: video.likes || [],
        stars: video.stars || [],
        commentCount: video.comments?.length || 0,
        author: {
          username: video.user?.username,
          fullName: video.user?.fullName,
          country: video.user?.country,
          isVerified: video.user?.isVerified,
          profilePicture: video.user?.profilePicture
        }
      });
    });

    // HASHTAGS
    const hashtagMap = {};
    hashtagPosts.forEach(post => {
      post.hashtags?.forEach(tag => {
        if (tag.toLowerCase().includes(q.toLowerCase())) {
          hashtagMap[tag] = (hashtagMap[tag] || 0) + 1;
        }
      });
    });

    Object.entries(hashtagMap)
      .slice(0, 20)
      .forEach(([tag, count]) => {
        results.push({ type: "hashtags", tag, postCount: count });
      });

    // SORT
    results.sort((a, b) => {
      const scoreDiff = (b.score || 0) - (a.score || 0);
      if (Math.abs(scoreDiff) < 20) return Math.random() - 0.5;
      return scoreDiff;
    });

    // LOG SEARCH BEHAVIOR
    if (userId) {
      await User.findByIdAndUpdate(userId, {
        $inc: { [`feedPreferences.${q.toLowerCase()}`]: 1 }
      });
    }

    return res.json({ results });

  } catch (err) {
    console.error("SEARCH ERROR:", err);
    return res.status(500).json({ message: "Search failed" });
  }
};
