const ExplorePost = require("../models/ExplorePost");
const ExploreComment = require("../models/ExploreComment");



exports.createExplorePost = async (req, res) => {
  try {
    const { title, text, category, region, isQuestion } = req.body;

    let images = [];
    let video = null;

    if (req.files?.length) {
      req.files.forEach(file => {
        if (file.mimetype.startsWith("image/")) {
          images.push(file.path || file.secure_url);
        }
        if (file.mimetype.startsWith("video/")) {
          video = file.path || file.secure_url;
        }
      });
    }

    if (!text && images.length === 0 && !video) {
      return res.status(400).json({ message: "Post cannot be empty" });
    }

    const post = await ExplorePost.create({
      user: req.user.id,
      title,
      text,
      category,
      region: region || "Africa",
      isQuestion: isQuestion === "true" || isQuestion === true,
      images,
      video
    });

    await post.populate("user", "username fullName profilePicture country isVerified");

    res.status(201).json(post);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to create post" });
  }
};






exports.getExploreFeed = async (req, res) => {
  try {
    const { page = 1, limit = 20, type } = req.query;

    const currentUserId = req.user?.id;

    let filter = { isDeleted: false };

    if (type === "ask") filter.isQuestion = true;
    if (type === "post") filter.isQuestion = false;

    // OPTIONAL: get user interests (for personalization)
    let userInterests = [];

    if (currentUserId) {
      const user = await require("../models/User")
        .findById(currentUserId)
        .select("interests");

      userInterests = user?.interests || [];
    }

    // ===============================
    // FETCH POSTS
    // ===============================
    const posts = await ExplorePost.find(filter)
  .populate(
    "user",
    "fullName username country profilePicture isVerified"
  )
  .sort({ createdAt: -1 })
  .skip((parseInt(page) - 1) * parseInt(limit))
  .limit(parseInt(limit))
  .lean();

    const now = Date.now();

    // ===============================
    // RANK POSTS
    // ===============================
    const ranked = posts.map(post => {

      const likes = post.likeCount || 0;
      const stars = post.starCount || 0;
      const comments = post.commentCount || 0;
      const upvotes = post.upvoteCount || 0;
      const downvotes = post.downvoteCount || 0;
      const views = post.viewCount || 0;

      let score =
        (likes * 2) +
        (stars * 3) +
        (comments * 2.5) +
        (upvotes * 4) +
        (views * 0.3) -
        (downvotes * 3);

      // ===============================
      // TIME DECAY
      // ===============================
      const ageHours =
        (now - new Date(post.createdAt).getTime()) /
        (1000 * 60 * 60);

      const decay = Math.exp(-ageHours / 24);

      score *= decay;

      // ===============================
      // QUESTION BOOST
      // ===============================
      if (post.isQuestion) {
        score *= 1.3;
      }

      // ===============================
      // INTEREST BOOST
      // ===============================
      if (userInterests.length && post.category) {

        if (userInterests.includes(post.category)) {
          score *= 1.2;
        }
      }

      // ===============================
      // OWN POST LOGIC
      // ===============================
      const isOwnPost =
        currentUserId &&
        post.user?._id?.toString() ===
        currentUserId.toString();

      if (isOwnPost) {

        if (ageHours < 24) {
          score *= 1.15;
        } else {
          score *= 0.85;
        }
      }

      return {
        ...post,
        score,
        totalVotes: upvotes - downvotes,
        views,
        isOwnPost
      };
    });

    // ===============================
    // SORT BY SCORE
    // ===============================
    ranked.sort((a, b) => b.score - a.score);

    // ===============================
    // FINAL PAGINATED RESPONSE
    // ===============================
    res.json({
      posts: ranked
    });

  } catch (err) {

    console.error("EXPLORE FEED ERROR:", err);

    res.status(500).json({
      message: "Failed to load explore feed"
    });
  }
};

      



exports.viewPost = async (req, res) => {
  try {
    const post = await ExplorePost.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user?.id;

    if (userId && !post.viewedBy.includes(userId)) {
      post.viewedBy.push(userId);
      post.viewCount++;
      await post.save();
    }

    res.json({
      views: post.viewCount
    });

  } catch {
    res.status(500).json({ message: "View failed" });
  }
};




exports.upvotePost = async (req, res) => {
  try {
    const post = await ExplorePost.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user.id;

    const hasUpvoted = post.upvotedBy.includes(userId);
    const hasDownvoted = post.downvotedBy.includes(userId);

    if (hasUpvoted) {
      post.upvotedBy.pull(userId);
      post.upvoteCount--;
    } else {
      post.upvotedBy.push(userId);
      post.upvoteCount++;

      if (hasDownvoted) {
        post.downvotedBy.pull(userId);
        post.downvoteCount--;
      }
    }

    await post.save();

    res.json({
      upvoted: !hasUpvoted,
      upvotes: post.upvoteCount,
      downvotes: post.downvoteCount
    });

  } catch {
    res.status(500).json({ message: "Upvote failed" });
  }
};





exports.downvotePost = async (req, res) => {
  try {
    const post = await ExplorePost.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user.id;

    const hasDownvoted = post.downvotedBy.includes(userId);
    const hasUpvoted = post.upvotedBy.includes(userId);

    if (hasDownvoted) {
      post.downvotedBy.pull(userId);
      post.downvoteCount--;
    } else {
      post.downvotedBy.push(userId);
      post.downvoteCount++;

      if (hasUpvoted) {
        post.upvotedBy.pull(userId);
        post.upvoteCount--;
      }
    }

    await post.save();

    res.json({
      downvoted: !hasDownvoted,
      upvotes: post.upvoteCount,
      downvotes: post.downvoteCount
    });

  } catch {
    res.status(500).json({ message: "Downvote failed" });
  }
};





exports.likePost = async (req, res) => {
  try {
    const post = await ExplorePost.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user.id;
    const liked = post.likedBy.includes(userId);

    if (liked) {
      post.likedBy.pull(userId);
      post.likeCount--;
    } else {
      post.likedBy.push(userId);
      post.likeCount++;
    }

    await post.save();

    res.json({
      liked: !liked,
      likeCount: post.likeCount
    });

  } catch {
    res.status(500).json({ message: "Like failed" });
  }
};





exports.starPost = async (req, res) => {
  try {
    const post = await ExplorePost.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user.id;
    const starred = post.starredBy.includes(userId);

    if (starred) {
      post.starredBy.pull(userId);
      post.starCount--;
    } else {
      post.starredBy.push(userId);
      post.starCount++;
    }

    await post.save();

    res.json({
      starred: !starred,
      starCount: post.starCount
    });

  } catch {
    res.status(500).json({ message: "Star failed" });
  }
};



exports.getExplorePost = async (req, res) => {
  try {
    const post = await ExplorePost.findById(req.params.postId)
      .populate("user", "fullName username country profilePicture isVerified");

    if (!post) {
      return res.status(404).json({ message: "Not found" });
    }

    const userId = req.user?.id;

    if (userId && !post.viewedBy.includes(userId)) {
      post.viewedBy.push(userId);
      await post.save();
    }

    const comments = await ExploreComment.find({ post: post._id })
      .populate("user", "fullName username country profilePicture isVerified")
      .sort({ createdAt: 1 });

    res.json({
      post: {
        ...post.toObject(),
        views: post.viewedBy.length,
        totalVotes: (post.upvotes || 0) + (post.downvotes || 0)
      },
      comments
    });

  } catch (err) {
    res.status(500).json({ message: "Failed to load post" });
  }
};




exports.getExploreHighlights = async (req, res) => {
  try {
    const posts = await ExplorePost.find({ isDeleted: false })
      .populate("user", "username fullName country profilePicture isVerified")
      .sort({ createdAt: -1 })
      .limit(5);

    res.json({ posts });

  } catch (err) {
    console.error("EXPLORE HIGHLIGHT ERROR:", err);
    res.status(500).json({ message: "Failed to load explore highlights" });
  }
};
