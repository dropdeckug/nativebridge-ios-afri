const UserSession = require("../models/UserSession");



// START SESSION
exports.startSession = async (req, res) => {
  try {
    const session = await UserSession.create({
      user: req.user.id
    });

    res.json({ sessionId: session._id });
  } catch (err) {
    res.status(500).json({ message: "Failed to start session" });
  }
};



// HEARTBEAT
exports.heartbeat = async (req, res) => {
  try {
    const { sessionId } = req.body;

    const session = await UserSession.findById(sessionId);
    if (!session || !session.isActive) return res.sendStatus(200);

    const now = new Date();

    const diff = Math.floor((now - session.lastActive) / 1000);

    // Only count real activity (avoid huge jumps)
    const safeDiff = Math.min(diff, 30); // max 30 seconds per ping

    if (safeDiff > 0) {
      session.duration += safeDiff;
    }

    session.lastActive = now;
    await session.save();

    res.sendStatus(200);
  } catch {
    res.sendStatus(200);
  }
};



// END SESSION
exports.endSession = async (req, res) => {
  try {
    const { sessionId } = req.body;

    const session = await UserSession.findById(sessionId);
    if (!session) return res.sendStatus(200);

    session.isActive = false;
    await session.save();

    res.sendStatus(200);
  } catch {
    res.sendStatus(200);
  }
};
