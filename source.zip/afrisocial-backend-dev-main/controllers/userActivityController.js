// controllers/userActivityController.js
const UserActivity = require("../models/UserActivity");
/**
 * Log a user activity
 * @param {String} userId - ID of the user performing the action
 * @param {String} type - type of activity: 'post', 'like', 'comment', 'view', 'login', etc.
 * @param {String|null} target - optional target ID (post, comment, etc.)
*/
exports.logActivity = async (userId, type, target = null) => {
  try {
    await UserActivity.create({
      user: userId,
      type,      // e.g., 'post', 'like', 'comment'
      target     // optional, e.g., postId or commentId
    });
  } catch (err) {
    console.error("Failed to log user activity:", err);
  }
};
