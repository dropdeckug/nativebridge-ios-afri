const Install = require("../models/Install");
const UserActivity = require("../models/UserActivity");
const axios = require("axios");

exports.recordInstall = async (req, res) => {
  try {
    // Get user IP from x-forwarded-for header or fallback
    let ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
    if (ip.includes(",")) ip = ip.split(",")[0].trim();

    const userAgent = req.headers["user-agent"];
    let country = "Unknown";
    let city = "Unknown";

    // Skip geolocation for localhost testing
    if (ip !== "127.0.0.1" && ip !== "::1") {
      try {
        const geo = await axios.get(`http://ip-api.com/json/${ip}?fields=status,country,city`);
        if (geo.data.status === "success") {
          country = geo.data.country;
          city = geo.data.city;
        }
      } catch (err) {
        console.log("Geo lookup failed:", err.message);
      }
    }

    await Install.create({
      user: req.user._id,
      ip,
      device: userAgent,
      browser: userAgent,
      country,
      city
    });

    res.status(201).json({ success: true });
  } catch (err) {
    console.error("Install tracking error:", err);
    res.status(500).json({ message: "Failed to record install" });
  }
};


// ACTIVE USERS STATS (DAU/WAU/MAU)
exports.getActiveUsersStats = async (req, res) => {
  try {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Distinct users in each period
    const dailyActiveUsers = await UserActivity.distinct("user", { createdAt: { $gte: oneDayAgo } });
    const weeklyActiveUsers = await UserActivity.distinct("user", { createdAt: { $gte: sevenDaysAgo } });
    const monthlyActiveUsers = await UserActivity.distinct("user", { createdAt: { $gte: thirtyDaysAgo } });

    // Engagement counts
    const activities = await UserActivity.aggregate([
      { $match: { createdAt: { $gte: thirtyDaysAgo } } },
      { $group: { _id: "$type", count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      stats: {
        dailyActiveUsers: dailyActiveUsers.length,
        weeklyActiveUsers: weeklyActiveUsers.length,
        monthlyActiveUsers: monthlyActiveUsers.length,
        engagement: activities
      }
    });
  } catch (err) {
    console.error("Active users stats error:", err);
    res.status(500).json({ message: "Failed to fetch active users stats" });
  }
};
