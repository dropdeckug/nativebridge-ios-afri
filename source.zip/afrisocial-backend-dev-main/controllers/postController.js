const Post = require("../models/Post");
const Poll = require("../models/Poll");
const Comment = require("../models/Comment");
const Notification = require("../models/Notification");
const { sendPushNotification } = require("./notificationController");
const User = require("../models/User");
const { logActivity } = require("./userActivityController");
const { handleMentions } = require("../utils/mentionHelper");
const activateReferral = require("../utils/activateReferral");
const updateFeedPreferences = require("../utils/updateFeedPreferences");
const generateVideoThumbnail = require("../utils/generateVideoThumbnail");

// CREATE POST
exports.createPost = async (req, res) => {
  try {
    const { text } = req.body;

    const images = [];
    let video = null;
    let videoThumbnail = "";

    if (req.files) {

  for (const file of req.files) {

    if (file.mimetype.startsWith("image/")) {

      images.push(file.path);

    }

    if (file.mimetype.startsWith("video/")) {

      video = file.path;

      videoThumbnail =
        await generateVideoThumbnail(file.path);

    }

  }

}

    if (!text && images.length === 0 && !video) {
      return res.status(400).json({ message: "Post cannot be empty" });
    }

    // Extract hashtags from post text
    const hashtagRegex = /#(\w+)/g;
    const hashtags = [];
    let match;
    if (text) {
    while ((match = hashtagRegex.exec(text)) !== null) {
    hashtags.push(match[1].toLowerCase());
     }
   }

    const post = await Post.create({
      user: req.user.id,
      text,
      images,
      video, 
      videoThumbnail,
      hashtags
    });

    await post.populate("user", "username fullName profilePicture country isVerified");

    // ===== LOG POST ACTIVITY =====
    await logActivity(req.user.id, "post", post._id);

    // HANDLE MENTIONS
    const mentions = await handleMentions(text, req.user.id, "post", post._id);

    post.mentions = mentions;
    await post.save();

    await post.populate("mentions", "username fullName profilePicture");

 // =========================
// UPDATE USER POST COUNT
// =========================

await User.findByIdAndUpdate(
  req.user.id,
  {
    $inc: {
      totalPosts: 1
    }
  }
);

// =========================
// CHECK REFERRAL ACTIVATION
// =========================

await activateReferral(
  req.user.id
);

    res.status(201).json(post);

  } catch (err) {
    console.error("CREATE POST ERROR:", err);
    res.status(500).json({ message: "Failed to create post" });
  }
};




exports.createComment = async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId);

    const comment = await Comment.create({
      post: post._id,
      user: req.user.id,
      text: req.body.text
    });


    // HANDLE MENTIONS IN COMMENT
    const mentions =  await handleMentions(req.body.text, req.user.id, "comment", comment._id);

    comment.mentions = mentions;
    await comment.save();

    await comment.populate("mentions", "username fullName profilePicture");

    await updateFeedPreferences(
    req.user.id,
    post.hashtags,
    4
   );

    // LOG COMMENT ACTIVITY
    await logActivity(req.user.id, "comment", comment._id);

 // Increase total comments
await User.findByIdAndUpdate(
  req.user.id,
  {
    $inc: {
      totalComments: 1
    }
  }
);

// Check referral activation
await activateReferral(
  req.user.id
);

    // NOTIFICATION
    if (post.user.toString() !== req.user.toString()) {
      await Notification.create({
        recipient: post.user,
        sender: req.user,
        type: "comment",
        post: post._id,
        comment: comment._id
      });
    }

    res.status(201).json(comment);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};






exports.getFeed = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const currentUser = await User.findById(req.user.id)
   .select('interests following blockedUsers blockedBy feedPreferences');

    const userInterests = currentUser?.interests || [];
    const followingIds = currentUser?.following || [];
    const behaviorPreferences = currentUser?.feedPreferences || {};

  // BLOCK FILTER
   const hiddenUsers = [
  ...(currentUser.blockedUsers || []),
  ...(currentUser.blockedBy || [])
];

    // ===============================
    // FETCH POSTS (RELAXED)
    // ===============================
     const followingPosts = await Post.find({
      user: { $in: followingIds, $ne: req.user.id, $nin: hiddenUsers },
      createdAt: { $gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) } // 90 DAYS
    })
      .sort({ createdAt: -1 })
      .limit(300)
      .populate("user", "username fullName profilePicture country isVerified followers")
      .populate("mentions", "username fullName profilePicture");

      const explorePosts = await Post.find({
      user: { $nin: [...followingIds, req.user.id, ...hiddenUsers] },
      createdAt: { $gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) } // 90 DAYS
    })
      .sort({ createdAt: -1 })
      .limit(500)
      .populate("user", "username fullName profilePicture country isVerified followers")
      .populate("mentions", "username fullName profilePicture");

 // ===============================
// REMOVE OLD BIRTHDAY POSTS
// ===============================

const today = new Date();

today.setHours(0, 0, 0, 0);

const tomorrow = new Date(today);

tomorrow.setDate(tomorrow.getDate() + 1);

// ONLY KEEP:
// - normal posts
// - today's birthday posts

const filteredFollowingPosts = followingPosts.filter(post => {

  // normal post
  if (!post.isBirthdayPost) return true;

  // birthday post → only today
  const created = new Date(post.createdAt);

  return created >= today && created < tomorrow;

});

const filteredExplorePosts = explorePosts.filter(post => {

  // normal post
  if (!post.isBirthdayPost) return true;

  // birthday post → only today
  const created = new Date(post.createdAt);

  return created >= today && created < tomorrow;

});

// FINAL POSTS
const allPosts = [
  ...filteredFollowingPosts,
  ...filteredExplorePosts
];

   // ===============================
  // FETCH SPONSORED POSTS
  // ===============================
   const sponsoredPosts = await Post.find({
   isSponsored: true,
   user: { $nin: hiddenUsers },

   $or: [
    { expiresAt: null },
    { expiresAt: { $gt: new Date() } }
   ]
  })
  .sort({ createdAt: -1 })
  .limit(20)
  .populate(
  "user",
  "username fullName profilePicture country isVerified followers"
  )
  .populate(
  "mentions",
  "username fullName profilePicture"
  );

 // RANDOM ROTATION
  const shuffledSponsored = sponsoredPosts.sort(
  () => 0.5 - Math.random()
  ); 

   // ===============================
  // FETCH POLLS (FOLLOWING + DISCOVERY)
  // ===============================
  const followingPolls = await Poll.find({
  user: { $in: followingIds, $nin: hiddenUsers },
  createdAt: { $gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) }
  })
  .sort({ createdAt: -1 })
  .limit(200)
  .populate("user", "username fullName profilePicture country isVerified followers");

  const explorePolls = await Poll.find({
  user: { $nin: [...followingIds, ...hiddenUsers] },
  createdAt: { $gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) }
  })
  .sort({ createdAt: -1 })
  .limit(300)
  .populate("user", "username fullName profilePicture country isVerified followers");

   const allPolls = [...followingPolls, ...explorePolls];

  // ===============================
 // SCORE POSTS
// ===============================
const postIds = allPosts.map(p => p._id);
const commentCountAgg = await Comment.aggregate([
  { $match: { post: { $in: postIds } } },
  { $group: { _id: "$post", count: { $sum: 1 } } }
]);
const commentCounts = new Map(commentCountAgg.map(c => [String(c._id), c.count]));

const scoredPosts = await Promise.all(
  allPosts.map(async (post) => {

    const commentCount = commentCounts.get(String(post._id)) || 0;

    const likes = post.likes.length;
    const stars = post.stars.length;
    const views = post.views || 0;

    const hoursAgo =
      (Date.now() - new Date(post.createdAt)) /
      (1000 * 60 * 60);

// INTEREST + SEARCH BEHAVIOR BOOST
let interestBoost = 0;

// hashtag matching
if (post.hashtags) {
  post.hashtags.forEach(tag => {

    if (userInterests.includes(tag)) {
      interestBoost += 6;
    }

    const behaviorScore =
      behaviorPreferences.get(tag) || 0;

    interestBoost += behaviorScore * 0.5;
  });
}

// text matching from search history
Object.keys(
  Object.fromEntries(behaviorPreferences)
).forEach(keyword => {

  if (
    post.text &&
    post.text.toLowerCase().includes(
      keyword.toLowerCase()
    )
  ) {
    interestBoost +=
      behaviorPreferences.get(keyword);
  }
});

    // FOLLOWING BOOST
    const isFollowing = followingIds.some(id =>
      id.toString() === post.user._id.toString()
    );

    let followingBoost = isFollowing ? 8 : 0;

    // VIDEO BOOST
    let videoBoost = post.video ? 6 : 0;

    // FRESH BOOST
    let freshBoost = 0;

    if (hoursAgo < 1) freshBoost = 12;
    else if (hoursAgo < 6) freshBoost = 8;
    else if (hoursAgo < 24) freshBoost = 5;
    else if (hoursAgo < 72) freshBoost = 2;

    // LOW ENGAGEMENT BOOST
    let lowEngagementBoost = 0;

    if (likes < 5 && commentCount < 3) {
      lowEngagementBoost = 20;
    }

    // SMALL CREATOR BOOST
    const followerCount =
      post.user.followers?.length || 0;

    let newUserBoost =
      followerCount < 50 ? 20 : 0;

    // RANDOM BOOST
    let randomBoost = Math.random() * 18;

    // ===============================
    // SEEN / UNSEEN SYSTEM
    // ===============================
    let seenPenalty = 0;

    const hasSeen =
      post.viewedBy?.some(
        id => id.toString() === req.user.id.toString()
      );

    // push seen posts lower
    // but DON'T remove them
    if (hasSeen) {
      seenPenalty = -150;
    } else {
      // unseen boost
      seenPenalty = 40;
    }

    // ===============================
    // FINAL SCORE
    // ===============================

    // Prevent search history from dominating feed
    interestBoost = Math.min(interestBoost, 30);
    
    const score =
      (likes * 1) +
      (stars * 1.5) +
      (commentCount * 1.5) +
      (views * 0.5) +
      interestBoost +
      followingBoost +
      videoBoost +
      freshBoost +
      lowEngagementBoost +
      newUserBoost +
      randomBoost +
      seenPenalty -
      (hoursAgo * 0.2);

    return {
      ...post.toObject(),
      commentCount,
      score
    };
  })
);
    
    // ===============================
    // SORT
    // ===============================
    scoredPosts.sort((a, b) => b.score - a.score);
    
  // ===============================
 // SCORE POLLS
// ===============================
const scoredPolls = allPolls.map(poll => {

  const totalVotes = poll.options?.reduce(
    (s, o) => s + (o.votes || 0),
    0
  );

  const reactionCount = poll.reactions?.length || 0;

  const hoursAgo =
    (Date.now() - new Date(poll.createdAt)) /
    (1000 * 60 * 60);

  // ===============================
  // REACTION BOOST
  // ===============================
  let reactionBoost = 0;

  if (reactionCount > 0) {
    reactionBoost = reactionCount * 1.2;
  }

  if (reactionCount > 20) {
    reactionBoost += 15;
  }

  // ===============================
  // INTEREST BOOST
  // ===============================
  let interestBoost = 0;

  if (poll.question) {
    userInterests.forEach(tag => {
      if (
        poll.question
          .toLowerCase()
          .includes(tag.toLowerCase())
      ) {
        interestBoost += 8;
      }
    });
  }

  // ===============================
  // FOLLOWING BOOST
  // ===============================
  const isFollowing = followingIds.some(
    id => id.toString() === poll.user._id.toString()
  );

  let followingBoost = isFollowing ? 10 : 0;

  // ===============================
  // FRESH BOOST
  // ===============================
  let freshBoost = 0;

  if (hoursAgo < 1) freshBoost = 40;
  else if (hoursAgo < 6) freshBoost = 25;
  else if (hoursAgo < 24) freshBoost = 12;

  // ===============================
  // LOW ENGAGEMENT BOOST
  // ===============================
  let lowEngagementBoost =
    totalVotes < 5 ? 25 : 0;

  // ===============================
  // SMALL CREATOR BOOST
  // ===============================
  const followerCount =
    poll.user.followers?.length || 0;

  let newUserBoost =
    followerCount < 50 ? 20 : 0;

  // ===============================
  // RANDOM BOOST
  // ===============================
  let randomBoost = Math.random() * 5;

  // ===============================
  // SEEN POLL PENALTY
  // ===============================
  const hasSeen =
    poll.viewedBy?.some(
      id => id.toString() === req.user.id.toString()
    ) || false;

  let seenPenalty = hasSeen ? -40 : 15;

  // ===============================
  // FINAL SCORE
  // =============================== 
  const score =
    (totalVotes * 2) +
    (reactionCount * 1.2) +
    interestBoost +
    followingBoost +
    freshBoost +
    lowEngagementBoost +
    newUserBoost +
    reactionBoost +
    randomBoost +
    seenPenalty -
    (hoursAgo * 0.2);

  return {
    ...poll.toObject(),
    type: "poll",
    score
  };
});

// SORT POLLS
scoredPolls.sort((a, b) => b.score - a.score);
    
    // ===============================
    // LIGHT DIVERSITY (NOT STRICT)
    // ===============================
    const creatorCount = {};
    const finalFeed = [];

    let birthdayCounter = 0;

    for (let post of scoredPosts) {
   // ===============================
  // BIRTHDAY POST SPACING
  // ===============================
  if (post.isBirthdayPost) {

    birthdayCounter++;

    // skip every 2nd birthday post
    // so they don't stack together

    if (birthdayCounter > 1) {

      birthdayCounter = 0;

      continue;
    }
  }

      const uid = post.user._id.toString();
      creatorCount[uid] = creatorCount[uid] || 0;

      // Allow up to 5 posts per creator 
      if (creatorCount[uid] < 2) {
        finalFeed.push(post);
        creatorCount[uid]++;
      }
    }

   
// ===============================
// MIX POSTS + POLLS + SPONSORED
// ===============================
const mixedFeed = [];

let postIndex = 0;
let pollIndex = 0;
let sponsoredIndex = 0;

while (postIndex < finalFeed.length) {

  // ===============================
  // RANDOM CONTENT GAP
  // ===============================
  const contentGap =
    Math.floor(Math.random() * 3) + 4;
    // 4 → 6 posts before ad

  // ===============================
  // ADD POSTS
  // ===============================
  for (
    let i = 0;
    i < contentGap &&
    postIndex < finalFeed.length;
    i++
  ) {

    const post = finalFeed[postIndex++];

    if (post && post.user) {
      mixedFeed.push(post);
    }
  }

  // ===============================
  // ADD SPONSORED POST
  // ===============================
  const shouldInsertAd =
    shuffledSponsored.length > 0 &&
    Math.random() > 0.25;
    // 75% chance

  if (shouldInsertAd) {

    const sponsored =
      shuffledSponsored[
        sponsoredIndex %
        shuffledSponsored.length
      ];

    if (sponsored && sponsored.user) {

      mixedFeed.push({
        ...sponsored.toObject(),
        type: "sponsored"
      });

      sponsoredIndex++;
    }
  }

  // ===============================
  // RANDOM POLL INSERTION
  // ===============================
  const shouldInsertPoll =
    Math.random() > 0.4;
    // 60% chance

  if (shouldInsertPoll) {

    while (pollIndex < scoredPolls.length) {

      const poll =
        scoredPolls[pollIndex++];

      if (
        poll &&
        poll.user &&
        poll.options &&
        Array.isArray(poll.options)
      ) {

        mixedFeed.push(poll);

        break;
      }
    }
  }
}

// ===============================
// FINAL CLEAN
// ===============================
const cleanFeed = mixedFeed.filter(
  item => item && item.user
);

// ===============================
// PAGINATION
// ===============================
const paginatedFeed = cleanFeed.slice(skip, skip + limit);

res.json({
  posts: paginatedFeed,
  page,
  hasMore: cleanFeed.length > skip + limit
});
    

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch feed" });
  }
};
  





exports.getPostsByUser = async (req, res) => {
  try {
    const userId = req.params.userId;

    if (!userId) {
      return res.status(400).json({ message: "User ID required" });
    }

      const posts = await Post.find({ user: userId })
      
      .populate("user", "username fullName profilePicture country  isVerified")
      .populate("mentions", "username fullName profilePicture")
      .sort({ createdAt: -1 });

    const postsWithCommentCount = await Promise.all(
      posts.map(async post => {
        const commentCount = await Comment.countDocuments({ post: post._id });
        return { ...post.toObject(), commentCount };
      })
    );

    res.status(200).json({ posts: postsWithCommentCount });
  } catch (err) {
    console.error("GET USER POSTS ERROR:", err);
    res.status(500).json({ message: "Failed to fetch user posts" });
  }
};




// LIKE / UNLIKE POST
exports.likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user.id;
    const index = post.likes.indexOf(userId);

    if (index === -1) {
      post.likes.push(userId);

      await updateFeedPreferences(
       userId,
       post.hashtags,
      2
     );

      // Update user's totalLikes
  await User.findByIdAndUpdate(post.user, {
    $inc: { totalLikes: 1 }
  });

      // LOG LIKE ACTIVITY
      await logActivity(userId, "like", post._id);

// Increase engagement count
await User.findByIdAndUpdate(
  userId,
  {
    $inc: {
      totalLoves: 1
    }
  }
);

// Check referral activation
await activateReferral(
  userId
);

      // NOTIFICATION
      if (post.user.toString() !== userId) {
        await Notification.create({
          recipient: post.user,
          sender: userId,
          type: "like",
          post: post._id
        });
        const sender = await User.findById(userId);

      const payload = {
     title: "New Like",
     body: `${sender.fullName} liked ❤️ your post`,
     click_action: "/notification.html", 
     icon: sender.profilePicture 
  };

  await sendPushNotification(post.user, payload);
      }

    } else {
      post.likes.splice(index, 1);

       // Decrease user's totalLikes
  await User.findByIdAndUpdate(post.user, {
    $inc: { totalLikes: -1 }
      }); 
      
    }

    await post.save();
    res.json({ likes: post.likes, liked: index === -1 });

  } catch (err) {
    res.status(500).json({ message: "Like failed" });
  }
};



// STAR / UNSTAR POST
exports.starPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user.id;
    const index = post.stars.indexOf(userId);

    if (index === -1) {
      post.stars.push(userId);

      await updateFeedPreferences(
       userId,
       post.hashtags,
       3
     );

       // Update user's totalStars
  await User.findByIdAndUpdate(post.user, {
    $inc: { totalStars: 1 }
    });

      // ===== LOG STAR ACTIVITY =====
      await logActivity(userId, "star", post._id);

      // NOTIFICATION
      if (post.user.toString() !== userId) {
        await Notification.create({
          recipient: post.user,
          sender: userId,
          type: "star",
          post: post._id
        });
        const sender = await User.findById(userId);

      const payload = {
     title: "New Star",
     body: `${sender.fullName} starred ⭐ your post`,
     click_action: "/notification.html", 
     icon: sender.profilePicture 
  };

await sendPushNotification(post.user, payload);
      }

    } else {
      post.stars.splice(index, 1);

        // Decrease user's totalStars
  await User.findByIdAndUpdate(post.user, {
    $inc: { totalStars: -1 }
      });
      
    }

    await post.save();
    res.json({ stars: post.stars, starred: index === -1 });

  } catch (err) {
    res.status(500).json({ message: "Star failed" });
  }
};


exports.addVideoView = async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    // Don't count own post views
    if (post.user.toString() === req.user.id) {
      return res.json({ views: post.views });
    }

    // Already viewed
    if (post.viewedBy.includes(req.user.id)) {
      return res.json({ views: post.views });
    }

    // New view
    post.views += 1;
    post.viewedBy.push(req.user.id);
    await post.save();

    await updateFeedPreferences(
    req.user.id,
     post.hashtags,
     1
    );

    // ===== LOG VIDEO VIEW ACTIVITY =====
     await logActivity(req.user.id, "view", post._id);

    res.json({ views: post.views });
  } catch (err) {
    console.error("ADD VIDEO VIEW ERROR:", err);
    res.status(500).json({ message: "Failed to add view" });
  }
};



// DELETE a post
exports.deletePost = async (req, res) => {

  try {

    const post =
      await Post.findById(req.params.id);

    if (!post) {

      return res.status(404).json({
        message: "Post not found"
      });

    }

    // Only owner can delete
    if (
      post.user.toString() !==
      req.user.id
    ) {

      return res.status(403).json({
        message: "Not authorized"
      });

    }

    await post.deleteOne();

    res.json({
      success: true,
      message: "Post deleted"
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to delete post"
    });

  }

};






// Get a single post by ID
exports.getSinglePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId)
      .populate("user", "username fullName profilePicture country isVerified")
      .populate("mentions", "username fullName profilePicture");

    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    }

    // Add comment count
    const commentCount = await Comment.countDocuments({ post: post._id });

    res.json({
      ...post.toObject(),
      commentCount
    });

  } catch (err) {
    console.error("GET SINGLE POST ERROR:", err);
    res.status(500).json({ message: "Failed to fetch post" });
  }
};

      




// TRACK IMPRESSION
exports.trackImpression = async (req, res) => {
  try {

    const postId =
    req.params.id || req.params.videoId;

   const post = await Post.findById(postId);

    if (!post || !post.isSponsored) {
      return res.status(404).json({
        message: "Sponsored post not found"
      });
    }

    post.impressions += 1;

    await post.save();

    res.status(200).json({
      success: true
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to track impression"
    });
  }
};



// TRACK CLICK
exports.trackClick = async (req, res) => {
  try {

    const postId =
    req.params.id || req.params.videoId;

    const post = await Post.findById(postId);

    if (!post || !post.isSponsored) {
      return res.status(404).json({
        message: "Sponsored post not found"
      });
    }

    post.clicks += 1;

    await post.save();

    res.status(200).json({
      success: true,
      redirectUrl: post.redirectUrl
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to track click"
    });
  }
};






// Hashtag for post 
exports.getPostsByHashtag = async (req, res) => {
  try {
    const { tag } = req.params;

    const page = parseInt(req.query.page) || 1;
    const limit = 20;
    const skip = (page - 1) * limit;

    const normalizedTag = tag.toLowerCase();

    const totalPosts = await Post.countDocuments({
      hashtags: normalizedTag,
      isDeleted: false
    });

    const posts = await Post.find({
      hashtags: normalizedTag,
      isDeleted: false
    })
      .populate(
        "user",
        "username fullName profilePicture"
      )
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();

    const formattedPosts = posts.map(post => ({
      id: post._id,

      text: post.text || "",

      images: post.images || [],

      image:
        post.images && post.images.length > 0
          ? post.images[0]
          : null,

      video: post.video || null,

      thumbnail: post.videoThumbnail || null,

      likes: post.likes || [],

      stars: post.stars || [],

      commentCount: post.commentCount || 0,

      createdAt: post.createdAt,

      author: {
        username: post.user?.username || "",
        fullName: post.user?.fullName || "",
        profilePicture:
          post.user?.profilePicture ||
          "/uploads/images/africa.png"
      }
    }));

    res.status(200).json({
      posts: formattedPosts,
      totalPosts,
      currentPage: page,
      hasMore: skip + posts.length < totalPosts
    });

  } catch (err) {
    console.error("Hashtag fetch error:", err);

    res.status(500).json({
      message: "Failed to load hashtag posts"
    });
  }
};
