const User = require("../models/User");

const updateActiveStatus = async (req, res, next) => {
  if (req.user) { 
    await User.findByIdAndUpdate(req.user._id, {
      lastActiveAt: new Date(),
      isOnline: true
    });
  }
  next();
};

module.exports = updateActiveStatus;
