const User = require("../models/User");

module.exports = async (req, res, next) => {

  try {

    // only logged-in users
    if (req.user?._id) {

      await User.findByIdAndUpdate(
        req.user._id,
        {
          lastActive: new Date()
        }
      );

    }

  } catch (err) {

    console.error(
      "LAST ACTIVE ERROR:",
      err
    );

  }

  next();

};
