const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  fullName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: function () {
      return this.authProvider === "local";
    }
  },
  googleId: {
    type: String,
    default: null
  },
  authProvider: {
    type: String,
    enum: ["local", "google"],
    default: "local"
  }, 
  country: {
    type: String,
    required: true,
  },
  dob: {
    type: Date,
    required: true,
  },
  profilePicture: {
    type: String,
    default: "/uploads/images/africa.png"
  },
  bio: {
    type: String,
    default: ""
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  followers: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  ],
  following: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  ],
  fcmToken: {
    type: String,
    default: null
  }, 
  lastActiveAt: {
    type: Date,
    default: Date.now
  },
  isOnline: {
    type: Boolean,
    default: false
  }, 
  totalLikes: {
    type: Number,
    default: 0
  },
  totalStars: {
    type: Number,
    default: 0
  },
  interests: {
    type: [String],
    default: []
  },
  feedPreferences: {
    type: Map,
    of: Number,
    default: {}
  }, 
  phone: {
    type: String,
    default: ""
  },  
  contact: {
    type: String,
    default: ""
  },
  profession: {
    type: String,
    default: ""
  },
  africaIn: {
    type: String,
    default: ""
  },
  website: {
    type: String,
    default: ""
  },
  socials: {
    instagram: { type: String, default: "" },
    facebook:  { type: String, default: "" },
    x:         { type: String, default: "" },
    tiktok:    { type: String, default: "" },
    youtube:   { type: String, default: "" },
    linkedin:  { type: String, default: "" },
    snapchat:  { type: String, default: "" },
    threads:   { type: String, default: "" }
  },
  // Referral system
  referralCode: {
    type: String,
    unique: true,
    sparse: true
  },

  referredBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null
  },

  referralEarnings: {
    type: Number,
    default: 0
  },

  pendingReferralEarnings: {
    type: Number,
    default: 0
  },

  activeReferralCount: {
    type: Number,
    default: 0
  },

  totalReferralCount: {
    type: Number,
    default: 0
  },
  totalPosts: {
    type: Number,
    default: 0
  },

  totalComments: {
    type: Number,
    default: 0
  },
  totalLoves: {
    type: Number,
    default: 0
  },
  lastActive: {
    type: Date,
    default: Date.now
  },

  lastReEngagementEmail: {
    type: Date,
    default: null
  },

  role: {
    type: String,
    enum: ["user", "admin"],
    default: "user"
  }, 
  blockedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  blockedBy:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  resetPasswordToken: {
    type: String
  },
  resetPasswordExpires: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },

  // ════════════════════════════════
  // ADDED FOR MODERATION SYSTEM
  // ════════════════════════════════
  accountStatus: { 
    type: String, 
    enum: ['active', 'suspended', 'terminated'], 
    default: 'active', 
    index: true 
  },
  statusReason: { 
    type: String,
    default: ""
  },
  restrictedAt: {
    type: Date
  }
});

userSchema.index({
  username: "text",
  fullName: "text",
  bio: "text",
  country: "text"
});

module.exports = mongoose.model("User", userSchema);
