const mongoose = require("mongoose");

const storySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  media: {
    type: String,
    required: true
  },

  caption: {
    type: String,
    default: ""
  },

  viewers: [
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    reacted: {
      type: String,
      default: null 
    },
    viewedAt: {
      type: Date,
      default: Date.now
    }
  }
],
  
  reactions: [
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    type: {
      type: String,
      required: true
    }
  }
],
  
  expiresAt: {
    type: Date,
    required: true
  }

}, { timestamps: true });

// Auto delete after 24h
storySchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model("Story", storySchema);
