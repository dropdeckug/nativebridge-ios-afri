const mongoose = require('mongoose'); 

const ModerationLogSchema = new mongoose.Schema({
  userId:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  contentId:   { type: String },
  contentType: { type: String },
  content:     { type: String },
  reasons:     [{ type: String }],
  severity:    { type: String },
  action:      { type: String },
  status:      { type: String, default: 'pending' },
  createdAt:   { type: Date, default: Date.now },
}); 

module.exports = mongoose.model('ModerationLog', ModerationLogSchema);
