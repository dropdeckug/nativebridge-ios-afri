const mongoose = require("mongoose");

const installSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  ip: String, 
  device: String,
  browser: String,
  country: String,
  city: String,
  installedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Install", installSchema);
