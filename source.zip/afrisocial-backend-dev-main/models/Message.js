const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
{
  conversation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Conversation"
  },

  group: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Group"
  },

  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  text: {
    type: String,
    default: ""
  },

  media: {
    type: String,
    default: ""
  },

  type: {
    type: String,
    enum: [
      "text",
      "image",
      "video",
      "document",
      "voice",
      "gift"
    ],
    default: "text"
  },

  voiceDuration: {
    type: String,
    default: ""
  },

  replyTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Message"
  },

  giftType: String,

  giftStars: {
    type: Number,
    default: 0
  },

  isRead: {
    type: Boolean,
    default: false
  },

  reactions: [
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      emoji: { type: String },
      createdAt: { type: Date, default: Date.now }
    }
  ]

},
{ timestamps: true }
);

module.exports = mongoose.model("Message", messageSchema);
