const mongoose = require("mongoose");

const exploreCommentSchema = new mongoose.Schema(
  {
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ExplorePost",
      required: true,
      index: true
    },

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    text: {
      type: String,
      required: true,
      trim: true
    },

    //  THREADING (VERY IMPORTANT)
    parentComment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ExploreComment",
      default: null
    },

    //  REPLIES CACHE 
    repliesCount: {
      type: Number,
      default: 0
    },

    //  ENGAGEMENT 
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    score: {
      type: Number,
      default: 0
    },

    isDeleted: {
      type: Boolean,
      default: false
    }

  },
  { timestamps: true }
);

// Index for fast thread loading
exploreCommentSchema.index({ post: 1, parentComment: 1 });

module.exports = mongoose.model("ExploreComment", exploreCommentSchema);
