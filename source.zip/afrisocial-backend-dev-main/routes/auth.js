const express = require('express');
const router = express.Router();
const { OAuth2Client } = require('google-auth-library');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

router.post('/google', async (req, res) => {
  try {

    const { credential } = req.body;

    if (!credential) {
      return res.status(400).json({ 
        message: 'No credential provided' 
      });
    }

    // Verify token is genuinely from Google
    const ticket = await client.verifyIdToken({
      idToken: credential,
      audience: process.env.GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    const { 
      email, 
      name, 
      picture, 
      sub: googleId 
    } = payload;

    // Check MongoDB for existing user
    let user = await User.findOne({ 
      email: email.toLowerCase() 
    });

    let isNewUser = false;

    if (user) {



      
      user.googleId = googleId;
      user.authProvider = 'google';

      // Only update picture if they still have default
      if (
        picture && 
        user.profilePicture === '/uploads/images/africa.png'
      ) {
        user.profilePicture = picture;
      }

      await user.save();

    } else {
      // ----------------------------------------
      // NEW USER — create fresh account
      // ----------------------------------------
      isNewUser = true;

      // Generate username from Google name
      // "ken syntax" becomes "kennysyntax"
      const baseUsername = name
        .toLowerCase()
        .replace(/\s+/g, '')
        .replace(/[^a-z0-9]/g, '')
        .substring(0, 15);

     
      let username = baseUsername;
      let counter = 1;
      while (await User.findOne({ username })) {
        username = `${baseUsername}${counter}`;
        counter++;
      }

      user = await User.create({
        fullName: name,
        email: email.toLowerCase(),
        username: username,
        googleId: googleId,
        profilePicture: picture || '/uploads/images/africa.png',
        authProvider: 'google',
        password: undefined,
        isVerified: false,
        interests: [],
        bio: '',
        // Temporary — user completes these on next screen
        country: 'Not set',
        dob: new Date('2000-01-01'),
      });
    }

    // Generate JWT — identical format to normal login
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Return identical format to normal login response
    return res.status(200).json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        username: user.username,
        fullname: user.fullName,
        email: user.email,
        country: user.country,
        dob: user.dob,
        interests: user.interests,
        profilePicture: user.profilePicture,
        isVerified: user.isVerified,
        needsProfileCompletion: isNewUser
      }
    });

  } catch (err) {
    console.error('Google auth error:', err);
    return res.status(401).json({ 
      message: 'Google authentication failed' 
    });
  }
});

module.exports = router;
