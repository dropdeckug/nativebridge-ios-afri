const express = require("express");
const router = express.Router();

const vybzeController = require("../controllers/vybzeController");
const postController = require("../controllers/postController");
const commentController = require("../controllers/commentController");
const protect = require("../middleware/auth");
const optionalAuth = require("../middleware/optionalAuth");

// Vybze feed
router.get("/feed", optionalAuth, vybzeController.getVybzeFeed);

// Vybze actions
router.post("/:videoId/like", protect, postController.likePost);
router.post("/:videoId/star", protect, postController.starPost);
router.post("/:videoId/comment", protect, commentController.createComment);
router.post("/:videoId/view", protect, postController.addVideoView);

// Get comments
router.get("/:videoId/comments", commentController.getCommentsByPost);

// Track video impressions 
router.post(
  "/:videoId/impression",
  protect,
  postController.trackImpression
);

// Track video click impressions 
router.post(
  "/:videoId/click",
  protect,
  postController.trackClick
);

// vybze single video 
router.get("/video/:videoId", vybzeController.getSingleVideo);

module.exports = router;
