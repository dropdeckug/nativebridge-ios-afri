const express = require("express");
const router = express.Router();

const auth = require("../middleware/auth");
const upload = require("../middleware/upload");

const {
  createExplorePost,
  getExploreFeed,
  getExplorePost,
  getExploreHighlights,
  viewPost,
  upvotePost,
  downvotePost,
  likePost,        
  starPost         
} = require("../controllers/exploreController");

// =====================
//  FEED (PUBLIC)
// =====================
router.get("/feed", getExploreFeed);
router.get("/highlights", getExploreHighlights);


// =====================
//  CREATE POST (PROTECTED)
// =====================
router.post("/", auth, upload.array("media", 6), createExplorePost);


// =====================
//  SINGLE POST (AUTO VIEW TRACK)
// =====================
router.get("/:postId", getExplorePost);


// =====================
//  VIEW TRACKING (OPTIONAL SEPARATE ENDPOINT)
// =====================
router.post("/:postId/view", auth, viewPost);


// =====================
//  VOTING SYSTEM
// =====================
router.post("/:postId/upvote", auth, upvotePost);
router.post("/:postId/downvote", auth, downvotePost);


// =====================
//  LIKE & STAR SYSTEM
// =====================
router.post("/:postId/like", auth, likePost);
router.post("/:postId/star", auth, starPost);


// =====================
//  (OPTIONAL FUTURE)
// =====================
// router.post("/:postId/share", auth, sharePost);
// router.post("/:postId/save", auth, savePost);


module.exports = router;
