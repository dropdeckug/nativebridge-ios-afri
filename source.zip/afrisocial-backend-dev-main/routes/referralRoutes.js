const express =
  require("express");

const router =
  express.Router();

const auth =
  require("../middleware/auth");

const {

  getDashboard,

  getLeaderboard

} = require(
  "../controllers/referralController"
);

router.get(
  "/dashboard",
  auth,
  getDashboard
);

router.get(
  "/leaderboard",
  getLeaderboard
);

module.exports = router;
