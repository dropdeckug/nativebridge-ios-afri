const express = require('express');
const router = express.Router();
const userController = require("../controllers/userController");
const protect = require("../middleware/auth");
const uploadProfilePic = require("../middleware/uploadProfilePic");
const updateActiveStatus = require("../middleware/updateActiveStatus");
const User = require("../models/User");
const BlockLog = require("../models/BlockLog");



// Suggested users
router.get("/suggested", protect, updateActiveStatus, userController.getSuggestedUsers);

router.get("/suggested-modal", protect, updateActiveStatus, userController.getSuggestedUsersModal);

// User search
router.get("/search", userController.searchUsers);

// Own profile
router.get("/me", protect, updateActiveStatus, userController.getMyProfile);
router.get("/me", protect, userController.getMe);

// Followers & Following lists
router.get("/:id/followers", protect, updateActiveStatus, userController.getFollowers);
router.get("/:id/following", protect, updateActiveStatus, userController.getFollowing);

// Public user profile
router.get("/:id", userController.getUserById);

// Follower / Unfollow
router.post("/follow/:id", protect, updateActiveStatus, userController.followUser);

// User Update Profile Page
router.put("/update-profile", protect, updateActiveStatus, uploadProfilePic.single("profilePicture"), userController.updateProfile);
// Protected route
router.get("/profile", protect, (req, res) => {
    res.json({
        message: "Access granted", userIdFromToken: req.user
    });
});

// Get active status of a user
router.get("/:id/active-status", protect, userController.getActiveStatus);

router.post("/offline", protect, userController.setOffline);

router.post("/online", protect, userController.setOnline);

// like and star counts 
router.get("/:userId/likes-stars", protect, userController.getUserLikesStars);

// Block a user
router.post('/block/:userId', protect, async (req, res) => {
  try {
    const { reason } = req.body;

    await User.findByIdAndUpdate(req.user.id, {
      $addToSet: { blockedUsers: req.params.userId }
    });

    await User.findByIdAndUpdate(req.params.userId, {
      $addToSet: { blockedBy: req.user.id }
    });

    // Log it
    await BlockLog.create({
      blocker: req.user.id,
      blocked: req.params.userId,
      reason
    });

    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Unblock a user
router.post('/unblock/:userId', protect, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user.id, {
      $pull: { blockedUsers: req.params.userId }
    });

    await User.findByIdAndUpdate(req.params.userId, {
      $pull: { blockedBy: req.user.id }
    });

    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Check block status
router.get('/block-status/:userId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .select('blockedUsers');

    const isBlocked = user.blockedUsers
      ?.includes(req.params.userId) || false;

    res.json({ isBlocked });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Signup route
router.post(
  "/signup",
  uploadProfilePic.single("profilePicture"),
  userController.signupUser
);

// Login route
router.post("/login", userController.loginUser);

// Forgot password route
router.post("/forgot-password", userController.forgotPassword);

// Reset password route
router.post("/new-password", userController.newPassword);

// change password 
router.post(
  "/change-password",
  protect,
  userController.changePassword
);

//logout routes 
router.post("/logout", protect, (req, res) => {
  res.json({ message: "Logged out successfully" });
});


module.exports = router;




