const express = require("express");
const router = express.Router();

const { recordInstall, getActiveUsersStats } = require("../controllers/analyticsController");
const auth = require("../middleware/auth");

// Track installs 
router.post("/install", auth, recordInstall);

// Get active users stats (DAU / WAU / MAU + engagement)
router.get("/active-users", auth, getActiveUsersStats);

module.exports = router;
