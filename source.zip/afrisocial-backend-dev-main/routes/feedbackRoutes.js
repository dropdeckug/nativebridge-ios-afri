const express = require("express");
const router = express.Router();
const feedbackController = require("../controllers/feedbackController");
const protect = require("../middleware/auth");

// Submit feedback (logged-in users)
router.post("/", protect, feedbackController.createFeedback);

// get all feedback (admin)
router.get("/", protect, feedbackController.getAllFeedback);

module.exports = router;
