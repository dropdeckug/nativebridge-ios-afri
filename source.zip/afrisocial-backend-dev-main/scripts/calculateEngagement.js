const mongoose = require("mongoose")
const User = require("../models/User")
const Post = require("../models/Post")

mongoose.connect(process.env.MONGO_URI)

const calculateUserEngagement = async () => {
  try {

    const users = await User.find()

    for (const user of users) {

      const posts = await Post.find({ user: user._id })

      let totalLikes = 0
      let totalStars = 0

      posts.forEach(post => {
        totalLikes += post.likes.length
        totalStars += post.stars.length
      })

      user.totalLikes = totalLikes
      user.totalStars = totalStars

      await user.save()
    }

    console.log("Likes and Stars calculated successfully")

    await mongoose.connection.close()
    process.exit()

  } catch (err) {
    console.error("Error calculating engagement:", err)
    process.exit(1)
  }
}

calculateUserEngagement()
