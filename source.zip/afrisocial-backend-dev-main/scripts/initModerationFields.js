const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');

// Pull the env config using a relative path to your root directory
dotenv.config({ path: path.join(__dirname, '../.env') });

const dbURI = process.env.MONGO_URI;

if (!dbURI) {
  console.error("❌ Error: MONGO_URI is missing from environment variables.");
  process.exit(1);
}

async function runMigration() {
  try {
    console.log('🔄 Connecting to MongoDB Cluster via Render environment...');
    await mongoose.connect(dbURI);
    console.log('✅ Connected successfully.');

    const db = mongoose.connection.db;

    // 1. Prepare existing posts for the dashboard queues
    console.log('📦 Initializing existing Posts with default moderation flags...');
    const postResult = await db.collection('posts').updateMany(
      { isDeleted: { $exists: false } },
      {
        $set: {
          isDeleted: false,
          moderationStatus: 'approved',
          moderationReason: ""
        }
      }
    );
    console.log(`✅ Posts initialized: Modified ${postResult.modifiedCount} documents.`);

    // 2. Prepare existing users for the account state management
    console.log('👤 Initializing existing Users with active statuses...');
    const userResult = await db.collection('users').updateMany(
      { accountStatus: { $exists: false } },
      {
        $set: {
          accountStatus: 'active',
          statusReason: ""
        }
      }
    );
    console.log(`✅ Users initialized: Modified ${userResult.modifiedCount} documents.`);

    console.log('🎉 Database initialization step complete! Ready for dashboard deployment.');
    process.exit(0);
  } catch (error) {
    console.error('❌ Database update failed:', error);
    process.exit(1);
  }
}

runMigration();
