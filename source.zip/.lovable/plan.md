## Plan: Fix Afrisocial messaging end-to-end

### What I found
- The frontend and backend message endpoints mostly line up, but the frontend can send weak/incorrect IDs when starting a DM, and the backend currently responds with generic errors.
- Login stores `data.user._id`, but the login API returns `user.id`, so `localStorage.userId` can become `undefined`. That can break message ownership/status logic in the UI.
- `createConversation` needs stricter validation and clearer responses for missing/invalid/self/blocked receiver IDs.
- Voice upload can fail because the upload pipeline is Cloudinary-dependent and audio handling must be treated separately from image/video transforms.
- Upload failures currently show only `Upload failed`; the UI should display the actual backend message.
- Server CORS should keep localhost and provide a clear editable allow-list for production/preview domains.

### Implementation steps
1. **Server CORS allow-list**
   - Replace the fragile inline regex-only setup with a clear `allowedOrigins` array plus regex support.
   - Include localhost defaults and Afrisocial domains.
   - Add a visible section/comment where you can add more accepted frontend URLs later.
   - Mirror the same allow logic for Socket.IO.

2. **Fix login/session user ID storage**
   - Update `log-in.js` so it stores `data.user.id || data.user._id` instead of only `_id`.
   - This makes `message.js` correctly know the logged-in sender ID.

3. **Harden DM conversation creation**
   - In `messageController.createConversation`, validate `receiverId` as a Mongo ObjectId.
   - Confirm the receiver user exists.
   - Return specific frontend-readable errors such as `Missing recipient`, `Invalid recipient`, `Recipient not found`, `Cannot message yourself`, or block-related reasons.
   - Keep support for `receiverId`, `userId`, `to`, and `recipientId`.

4. **Harden message sending**
   - In `sendMessage`, validate `conversationId`.
   - Confirm sender is actually a participant in the conversation before allowing send.
   - Return specific errors for invalid conversation, not a participant, empty message, blocked conversation, or save failure.
   - Keep realtime emits and notification creation as best-effort so notification bugs do not fail message delivery.

5. **Fix media/voice upload failures**
   - Keep audio uploads separate from image/video transformations.
   - Make `/upload-media` return the exact upload error message in JSON.
   - Validate uploaded URL and file type before responding.
   - Apply the same safe multer error handling to group photo upload if needed, but avoid changing unrelated upload flows.

6. **Frontend error visibility**
   - Improve the shared `api()` helper so errors include HTTP status and server message.
   - Update `uploadFile()` and voice-note upload to parse JSON/text error bodies instead of throwing generic `Upload failed`.
   - Show the full server message in the toast and on the failed bubble, so users see the real reason on-screen.

7. **Frontend ID/payload consistency**
   - Normalize user IDs from search/profile responses before calling `createConversation`.
   - Prevent sending if there is no valid active peer/conversation.
   - Send `voiceDuration` for voice notes when available.
   - Ensure the optimistic message is replaced only by a valid saved message object.

8. **Realtime delivery checks**
   - Confirm server emits `message:new` to the conversation room, recipient user room, and sender user room.
   - Confirm frontend joins the conversation after creating/opening a DM.
   - Keep notification creation after message save so delivery is not blocked by push notification failures.

9. **Mobile composer**
   - Keep the composer pinned at the bottom on small devices and ensure the message list has enough bottom space so the input does not cover messages.

### Files to update
- `afrisocial-backend-dev-main/server.js`
- `afrisocial-backend-dev-main/controllers/messageController.js`
- `afrisocial-backend-dev-main/routes/messageRoutes.js`
- `afrisocial-backend-dev-main/middleware/upload.js`
- `log-in.js`
- `message.js`
- `message.css` if the current mobile composer behavior still needs tightening

### Verification after implementation
- Start a DM from search and send a text message.
- Confirm `/api/messages/createConversation` returns `200` and `/api/messages/send` returns `201`.
- Confirm the saved message appears in the sender UI and is emitted in realtime to the recipient.
- Send a voice note and confirm `/api/messages/upload-media` returns `{ url, type: "voice" }`, then `/api/messages/send` returns `201`.
- Confirm frontend failures show the backend’s real message, not only `Message failed`.

### Deployment note
These backend fixes only affect the live `https://afrisocial-backend.onrender.com` API after the backend is redeployed on Render.