const User = require("../models/User");

async function isBlocked(userA, userB) {
  const [a, b] = await Promise.all([
    User.findById(userA).select("blockedUsers"),
    User.findById(userB).select("blockedUsers"),
  ]);

  if (!a || !b) return false;

  const aBlockedB = a.blockedUsers.some(
    id => id.toString() === userB.toString()
  );

  const bBlockedA = b.blockedUsers.some(
    id => id.toString() === userA.toString()
  );

  return aBlockedB || bBlockedA;
}

module.exports = { isBlocked };
