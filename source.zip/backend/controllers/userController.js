const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Notification = require("../models/Notification");
const Referral = require("../models/Referral");
const crypto = require("crypto");
const sendEmail = require("../utils/sendEmail");
const cloudinary = require("../config/cloudinary");
const { sendPushNotification } = require("./notificationController");
const { logActivity } = require("./userActivityController");
const UserActivity = require("../models/UserActivity");
const mongoose = require("mongoose");

// Referral code generator 
function generateReferralCode(username) {

  const random =
    Math.floor(
      1000 + Math.random() * 9000
    );

  return `${username}${random}`;
}


const dns = require("dns").promises; // Node.js DNS module for domain validation

// Simple email format check
const validateEmailFormat = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Check if email domain exists
const validateEmailDomain = async (email) => {
  const domain = email.split("@")[1];
  try {
    const addresses = await dns.resolveMx(domain);
    return addresses && addresses.length > 0;
  } catch (err) {
    return false; // domain does not exist or has no MX records
  }
};

exports.signupUser = async (req, res) => {
  try {
    const { username, fullName, email, password, country, dob, interests, bio, referralCode} = req.body;

    let parsedInterests = interests;

// Fix: convert string → array
   if (typeof parsedInterests === "string") {
   try {
   parsedInterests = JSON.parse(parsedInterests);
   } catch (err) {
     parsedInterests = [parsedInterests]; // fallback if single string
   }
 }

 // Ensure it's always an array
 if (!Array.isArray(parsedInterests)) {
  parsedInterests = [];
 }

  // Validate interest first 
   const VALID_INTERESTS = [
  'Business','Fashion','Sports','Cars','Tech',
  'Comedy','Music','Travel','Finance','Coding','Education'
  ];

   parsedInterests = parsedInterests.filter(i =>
   VALID_INTERESTS.includes(i.trim())
  );

    console.log("SIGNUP BODY", req.body);

    // Check required fields
    if (!username || !fullName || !email || !password || !country || !dob) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Validate email format
    if (!validateEmailFormat(email)) {
      return res.status(400).json({ message: "Invalid email format" });
    }

    // Validate email domain
    const isDomainValid = await validateEmailDomain(email);
    if (!isDomainValid) {
      return res.status(400).json({ message: "Email domain does not exist" });
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({ message: "Email already in use" });
    }

    // Check if username exists
    const existingUsername = await User.findOne({ username });
    if (existingUsername) {
      return res.status(400).json({ message: "Username already in use" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    // generate user own referral code
    const myReferralCode =  generateReferralCode(username);

    let referredBy = null;
    if (referralCode) {
    const referrer =
    await User.findOne({
      referralCode
    });
  if (referrer) {
    referredBy = referrer._id;
    referrer.totalReferralCount += 1;
    await referrer.save();
  }
}

    // Handle profile picture upload
    let profilePicture = "";

    if (req.file) {
    profilePicture = req.file.path;
   }

    const newUser = new User({
      username,
      fullName,
      email: email.toLowerCase(),
      password: hashedPassword,
      country,
      dob,
      interests: parsedInterests,
      bio, 
      profilePicture, 
      isVerified: false, 
      referralCode: myReferralCode,
      referredBy
    });

    await newUser.save();
    // create referral record 
    if (referredBy) {
    await Referral.create({
    referrer: referredBy,
    referredUser: newUser._id
  });
}

    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: "7d" });

    res.status(201).json({
      message: "User registered successfully",
      token,
      user: {
        id: newUser._id,
        username: newUser.username,
        fullname: newUser.fullName,
        email: newUser.email,
        country: newUser.country,
        dob: newUser.dob, 
        interests: newUser.interests
      }
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Registering failed" });
  }
};




exports.loginUser = async (req, res) => {
  try {
    // Get email & password from request body
    const { email, password } = req.body;

    // Debug log to check request
    console.log("LOGIN BODY", req.body);

    // ─── PROTECTION: FORCE STRING TYPE TO PREVENT CRASHES ────────────────────
    if (typeof email !== "string" || typeof password !== "string") {
      return res.status(400).json({ message: "Invalid email or password format." });
    }
    // ─────────────────────────────────────────────────────────────────────────

    // Find user by email (case-insensitive) safely now
    const user = await User.findOne({ email: email.toLowerCase() });
    
    // ─── SECURITY: GENERIC LOGIN RESPONSES ───────────────────────────────────
    // Old code leaked if the user existed ("User not found"). 
    // New code uses the same vague message for a missing email OR wrong password.
    if (!user) {
      return res.status(400).json({ message: "Invalid email or password." });
    }

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid email or password." });
    }
    // ─────────────────────────────────────────────────────────────────────────

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id },          // payload
      process.env.JWT_SECRET,        // secret key from .env
      { expiresIn: "7d" }            // token valid for 7 days
    );

    // Log user login
    await logActivity(user._id, "login");

    // Send success response
    res.status(200).json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        username: user.username,
        fullname: user.fullName,
        email: user.email,
        country: user.country,
        dob: user.dob,
        interests: user.interests,
        profilePicture: user.profilePicture
      }
    });

  } catch (err) {
    console.error(err);
    // Mask internal details from the attacker
    res.status(500).json({ message: "An error occurred during login." });
  }
};



// Users Profile Page (MY PROFILE)
exports.getMyProfile = async (req, res) => {
  try {
    const user = req.user; // already attached by auth middleware

    res.status(200).json({
      _id: user._id,
      username: user.username,
      fullName: user.fullName,
      country: user.country,
      bio: user.bio,
      profilePicture: user.profilePicture,
      createdAt: user.createdAt,
      socials: user.socials,
      profession: user.profession,
      contact: user.contact,
      website: user.website,
      africaIn: user.africaIn,
      email: user.email,
      phone: user.phone, 
      dob: user.dob,

      // FOLLOW SYSTEM
      followersCount: user.followers.length,
      followingCount: user.following.length, 
      isVerified: user.isVerified
    });

  } catch (err) {
    console.error("Get my profile error:", err);
    res.status(500).json({ message: "Failed to load profile" });
  }
};


// User Updte Profile Page
exports.updateProfile = async (req, res) => {
  try {
    const allowedFields = [
      "fullName",
      "username",
      "country",
      "bio",
      "contact",
      "profession",
      "africaIn",
      "website",
      "email",
      "phone", 
      "dob" 
    ];

    let updates = {};

    //  Only allow safe fields
    for (let key in req.body) {
      if (
        allowedFields.includes(key) ||
        key.startsWith("socials.")
      ) {
        updates[key] = req.body[key];
      }
    }

    //  Normalize + check username
    if (updates.username) {
      updates.username = updates.username.toLowerCase().trim();

      const existing = await User.findOne({
        username: updates.username,
        _id: { $ne: req.user.id }
      });

      if (existing) {
        return res.status(400).json({
          message: "Username already taken"
        });
      }
    }

    // Profile picture
    if (req.file) {
      updates.profilePicture = req.file.path;
    }

    // FIX: Added .select("-password") to ensure password hashes never leak in the HTTP response
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      { $set: updates },
      { new: true, runValidators: true }
    ).select("-password");

    res.status(200).json({
      message: "Profile updated",
      user: updatedUser
    });

  } catch (err) {
    console.error("Update error:", err);
    res.status(500).json({ message: "Failed to update profile" });
  }
};



// User search
exports.searchUsers = async (req, res) => {
  try {
    const query = req.query.q;

    if (!query) {
      return res.status(400).json({ message: "Search query is required" });
    }

    const users = await User.find({
      $or: [
        { username: { $regex: query, $options: "i" } },
        { fullName: { $regex: query, $options: "i" } }
      ]
    }).select("username fullName country profilePicture isVerified");

    res.status(200).json({ users });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Search failed" });
  }
};



// Public user profile
exports.getUserById = async (req, res) => {
  try {
    const userId = req.params.id;

    // PREVENT INVALID ID CRASH
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const viewedUser = await User.findById(userId)
      .select("username fullName bio country profilePicture createdAt socials contact profession website africaIn followers following isVerified");

    if (!viewedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    let isFollowing = false;

    // OPTIONAL auth
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.split(" ")[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      isFollowing = viewedUser.followers.includes(decoded.userId);
    }

    res.status(200).json({
      _id: viewedUser._id,
      username: viewedUser.username,
      fullName: viewedUser.fullName,
      bio: viewedUser.bio,
      country: viewedUser.country,
      profilePicture: viewedUser.profilePicture,
      createdAt: viewedUser.createdAt,
      socials: viewedUser.socials,
      profession: viewedUser.profession,
      contact: viewedUser.contact,
      website: viewedUser.website,
      africaIn: viewedUser.africaIn,
      followersCount: viewedUser.followers.length,
      followingCount: viewedUser.following.length,
      isVerified: viewedUser.isVerified,
      isFollowing
    });

  } catch (err) {
    console.error("GET USER ERROR:", err);
    res.status(500).json({ message: "Failed to load user profile" });
  }
};



// FOLLOW / UNFOLLOW USER
exports.followUser = async (req, res) => {
  try {
    const loggedInUserId = req.user._id;
    const targetUserId = req.params.id;

    if (loggedInUserId.toString() === targetUserId) {
      return res.status(400).json({ message: "You cannot follow yourself" });
    }

    const user = await User.findById(loggedInUserId);
    const targetUser = await User.findById(targetUserId);

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    const isFollowing = user.following.includes(targetUserId);

    if (isFollowing) {
      // UNFOLLOW
      user.following.pull(targetUserId);
      targetUser.followers.pull(loggedInUserId);
    } else {
      // FOLLOW
      user.following.push(targetUserId);
      targetUser.followers.push(loggedInUserId);

      // TRACK FOLLOW ACTIVITY
     await logActivity(loggedInUserId, "follow", targetUserId);

      // Create FOLLOW notification
      await Notification.create({
        recipient: targetUserId,
        sender: loggedInUserId,
        type: "follow"
      });

      const sender = await User.findById(loggedInUserId);
      const payload = {
      title: "New Follower",
      body: `${sender.fullName} started ➕👤 following you`,
      icon: sender.profilePicture || "/uploads/images/africa.png",
      data: {
      url: `/profile.html?id=${sender._id}`
     }
   };
  await sendPushNotification(targetUserId, payload);

      // Check if target user already follows logged-in user => FOLLOW_BACK notification
      if (user.followers.includes(targetUserId)) {
        await Notification.create({
          recipient: targetUserId,
          sender: loggedInUserId,
          type: "follow_back"
        });
      }
    }

    await user.save();
    await targetUser.save();

    res.status(200).json({
      message: isFollowing ? "Unfollowed" : "Followed",
      isFollowing: !isFollowing
    });

  } catch (err) {
    console.error("FOLLOW ERROR:", err);
    res.status(500).json({ message: "Follow action failed" });
  }
};


// Get followers list
exports.getFollowers = async (req, res) => {
  try {
    const loggedInUserId = req.user._id;
    const user = await User.findById(req.params.id)
      .populate("followers", "username fullName profilePicture country following isVerified");

    if (!user) return res.status(404).json({ message: "User not found" });

    // Map followers and check if logged-in user is following them
    const followersWithState = user.followers.map(follower => {
      return {
        _id: follower._id,
        username: follower.username,
        fullName: follower.fullName,
        profilePicture: follower.profilePicture,
        country: follower.country,
        isFollowing: follower.following.includes(loggedInUserId)
      };
    });

    res.status(200).json({ followers: followersWithState });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to load followers" });
  }
};

// Get following list
exports.getFollowing = async (req, res) => {
  try {
    const loggedInUserId = req.user._id;
    const user = await User.findById(req.params.id)
      .populate("following", "username fullName profilePicture country following isVerified");

    if (!user) return res.status(404).json({ message: "User not found" });

    const followingWithState = user.following.map(followed => {
      return {
        _id: followed._id,
        username: followed.username,
        fullName: followed.fullName,
        profilePicture: followed.profilePicture,
        country: followed.country,
        isFollowing: followed.following.includes(loggedInUserId)
      };
    });

    res.status(200).json({ following: followingWithState });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to load following" });
  }
};


// Suggested users list
exports.getSuggestedUsers = async (req, res) => {
  try {
    const currentUserId = req.user._id;

    // Get current user's following list
    const currentUser = await User.findById(currentUserId).select("following");

    // Get users NOT followed and exclude self
    const users = await User.find({
      _id: { $nin: [...currentUser.following, currentUserId] }
    }).select("fullName username profilePicture country isVerified");

    // Calculate activity score for each user (last 7 days)
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    const usersWithActivity = await Promise.all(
      users.map(async user => {
        const activityCount = await UserActivity.countDocuments({
          user: user._id,
          createdAt: { $gte: sevenDaysAgo }
        });
        return { ...user.toObject(), activityScore: activityCount };
      })
    );

    // Sort by activityScore descending
    usersWithActivity.sort((a, b) => b.activityScore - a.activityScore);

    // Limit to 100 users
    const suggested = usersWithActivity.slice(0, 100);

    res.status(200).json({ users: suggested });
  } catch (err) {
    console.error("GET SUGGESTED USERS ERROR:", err);
    res.status(500).json({ message: "Failed to get suggested users" });
  }
};



// Suggested user list mini modal
exports.getSuggestedUsersModal = async (req, res) => {
  try {
    const currentUserId = req.user._id;

    const currentUser = await User.findById(currentUserId).select("following");

    const suggested = await User.find({
      _id: { $nin: [...currentUser.following, currentUserId] }
    })
    .sort({ lastActiveAt: -1 })
    .limit(5)
    .select("fullName username profilePicture country isVerified");

    res.status(200).json({ users: suggested });
  } catch (err) {
    console.error("GET SUGGESTED USERS MODAL ERROR:", err);
    res.status(500).json({ message: "Failed to get suggested users for modal" });
  }
};




// GET logged-in user
exports.getMe = async (req, res) => {
  const user = await User.findById(req.user.id).select("-password");
  res.json(user);
};



// Forgotten password
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({
    email: email.toLowerCase()
    });
    
    if (!user) {
      // Do not reveal user existence
      return res.status(200).json({
        message: "If this email exists, a reset link has been sent"
      });
    }

    // Generate token and hash it before storing
    const resetToken = crypto.randomBytes(32).toString("hex");
    const hashedToken = crypto.createHash("sha256").update(resetToken).digest("hex");

    user.resetPasswordToken = hashedToken;
    user.resetPasswordExpires = Date.now() + 30 * 60 * 1000; // 30 mins
    await user.save();

    const resetUrl = `https://afrisocial.com.ng/new-password.html?token=${resetToken}`;

    const message = `
      <h2>Hello ${user.fullName},</h2>
      <p>Click the link below to reset your Afrisocial password:</p>
      <a href="${resetUrl}">Reset Password</a>
      <p>This link will expire in 30 minutes.</p>
    `;

    await sendEmail({

     to: user.email,

     subject: "Reset your Afrisocial password",

     html: message

   });

    res.status(200).json({
      message: "If this email exists, a reset link has been sent"
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Something went wrong" });
  }
};



// Reset password
exports.newPassword = async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    // Hash the token to match DB
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpires: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({ message: "Invalid or expired token" });
    }

    // Hash new password before saving
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;

    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;

    await user.save();

    res.status(200).json({ message: "Password reset successful" });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to reset password" });
  }
};



// USERS ACTIVE STATUS UPDATE
exports.getActiveStatus = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("isOnline lastActiveAt");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    let lastSeen = "unknown";

    if (user.lastActiveAt) {
      const lastActive = new Date(user.lastActiveAt).getTime();
      const diffMs = Date.now() - lastActive;

      const diffMinutes = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMinutes / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMinutes < 1) {
        lastSeen = "just now";
      } 
      else if (diffMinutes < 60) {
        lastSeen = `${diffMinutes}m ago`;
      } 
      else if (diffHours < 24) {
        lastSeen = `${diffHours}h ago`;
      } 
      else {
        lastSeen = `${diffDays}d ago`;
      }
    }

    res.json({
      isOnline: user.isOnline,
      lastSeen
    });

  } catch (err) {
    console.error("ACTIVE STATUS ERROR:", err);
    res.status(500).json({ message: "Failed to get active status" });
  }
};


// SET USER OFFLINE
exports.setOffline = async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user.id, {
      isOnline: false,
      lastActiveAt: new Date()
    });

    res.json({ success: true });

  } catch (err) {
    console.error("SET OFFLINE ERROR:", err);
    res.status(500).json({ message: "Failed to set offline" });
  }
};


// SET USER ONLINE
exports.setOnline = async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user.id, {
      isOnline: true,
      lastActiveAt: new Date()
    });

    res.json({ success: true });

  } catch (err) {
    console.error("SET ONLINE ERROR:", err);
    res.status(500).json({ message: "Failed to set online" });
  }
};



// GET user's total likes and stars
exports.getUserLikesStars = async (req, res) => {
  try {
    const userId = req.params.userId;
    const user = await User.findById(userId);

    if (!user) return res.status(404).json({ message: "User not found" });

    res.json({
      likes: user.totalLikes || 0,
      stars: user.totalStars || 0
    });
  } catch (err) {
    console.error("GET USER LIKES/STARS ERROR:", err);
    res.status(500).json({ message: "Failed to fetch user totals" });
  }
};





// Change password 
exports.changePassword = async (req, res) => {
  try {
    const userId = req.user.id;
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: "All fields are required" });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: "Password must be at least 6 characters" });
    }

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // BLOCK GOOGLE ACCOUNTS
    if (user.authProvider !== "local") {
      return res.status(400).json({
        message: "Google users cannot change password here"
      });
    }

    // VERIFY CURRENT PASSWORD
    const isMatch = await bcrypt.compare(currentPassword, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: "Current password is incorrect" });
    }

    // HASH NEW PASSWORD
    const salt = await bcrypt.genSalt(10);
    const hashed = await bcrypt.hash(newPassword, salt);

    user.password = hashed;

    await user.save();

    res.json({
      message: "Password updated successfully"
    });

  } catch (err) {
    console.error("CHANGE PASSWORD ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
};



