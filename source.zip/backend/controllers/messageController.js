const mongoose = require("mongoose");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const Notification = require("../models/Notification");
const User = require("../models/User");
const Group = require("../models/Group");
const { sendPushNotification } = require("./notificationController");
const { logActivity } = require("./userActivityController");
const { isBlocked } = require("../utils/blockCheck");

const POPULATE_PARTICIPANT = "username fullName profilePicture country isVerified";
const POPULATE_SENDER      = "username fullName profilePicture country isVerified";

/* ---------- helpers ---------- */
function emit(req, room, event, payload) {
  try {
    const io = req.app.get("io");
    if (io && room) io.to(room).emit(event, payload);
  } catch (_) {}
}

/* ---------- conversations ---------- */
exports.createConversation = async (req, res) => {
  try {
    const senderId = req.user._id;
    const body = req.body || {};
    const rawReceiverId = body.receiverId || body.userId || body.to || body.recipientId;
    const receiverId = rawReceiverId ? String(rawReceiverId).trim() : "";

    if (!senderId) {
      return res.status(401).json({ message: "Login required to start a conversation" });
    }
    if (!receiverId) {
      console.warn("CREATE CONV missing receiverId — body keys:", Object.keys(body));
      return res.status(400).json({ message: "Missing recipient" });
    }
    if (!mongoose.Types.ObjectId.isValid(receiverId)) {
      return res.status(400).json({ message: "Invalid recipient" });
    }
    if (String(receiverId) === String(senderId)) {
      return res.status(400).json({ message: "Cannot start a chat with yourself" });
    }
    const receiverExists = await User.exists({ _id: receiverId });
    if (!receiverExists) {
      return res.status(404).json({ message: "Recipient not found" });
    }
    if (await isBlocked(senderId, receiverId)) {
      return res.status(403).json({ message: "Cannot start conversation with this user." });
    }

    let conversation = await Conversation.findOne({
      participants: { $all: [senderId, receiverId], $size: 2 }
    }).populate("participants", POPULATE_PARTICIPANT);

    if (!conversation) {
      conversation = await Conversation.create({ participants: [senderId, receiverId] });
      conversation = await conversation.populate("participants", POPULATE_PARTICIPANT);
    } else {
      // un-archive on reopen
      await Conversation.updateOne(
        { _id: conversation._id },
        { $pull: { archivedBy: senderId } }
      );
    }

    res.status(200).json(conversation);
  } catch (err) {
    console.error("CREATE CONVERSATION ERROR:", err);
    res.status(500).json({ message: err.message || "Failed to create conversation" });
  }
};

async function listConversationsForUser(userId, { archived = false } = {}) {
  const me = await User.findById(userId).select("blockedUsers");
  const whoBlockedMe = await User.find({ blockedUsers: userId }).select("_id");
  const hiddenUsers = [
    ...(me?.blockedUsers || []).map(String),
    ...whoBlockedMe.map(u => u._id.toString()),
  ];

  const filter = {
    $and: [
      { participants: userId },
      { participants: { $nin: hiddenUsers } },
      archived
        ? { archivedBy: userId }
        : { $or: [{ archivedBy: { $exists: false } }, { archivedBy: { $ne: userId } }] }
    ]
  };

  const conversations = await Conversation.find(filter)
    .populate("participants", POPULATE_PARTICIPANT)
    .sort({ updatedAt: -1 });

  return Promise.all(conversations.map(async conv => {
    const otherUser = conv.participants.find(u => u._id.toString() !== userId.toString());
    const unreadCount = await Message.countDocuments({
      conversation: conv._id,
      sender: { $ne: userId },
      isRead: false
    });
    return {
      _id: conv._id,
      lastMessage: conv.lastMessage || "",
      updatedAt: conv.lastMessageAt || conv.updatedAt,
      otherUser,
      unreadCount
    };
  }));
}

exports.getConversations = async (req, res) => {
  try {
    res.json(await listConversationsForUser(req.user._id));
  } catch (err) {
    console.error("GET CONVERSATIONS ERROR:", err);
    res.status(500).json({ message: "Failed to load inbox" });
  }
};

// Alias used by the frontend (`/api/messages/chats`)
exports.getChats = exports.getConversations;

exports.getArchived = async (req, res) => {
  try {
    const chats  = await listConversationsForUser(req.user._id, { archived: true });
    const groups = await Group.find({ members: req.user._id, archivedBy: req.user._id })
      .select("name profilePicture lastMessage lastMessageAt updatedAt members")
      .sort({ updatedAt: -1 });
    res.json({ chats, groups });
  } catch (err) {
    console.error("GET ARCHIVED ERROR:", err);
    res.status(500).json({ message: "Failed to load archived" });
  }
};

exports.getConversation = async (req, res) => {
  try {
    const conversation = await Conversation.findById(req.params.conversationId)
      .populate("participants", POPULATE_PARTICIPANT);
    if (!conversation) return res.status(404).json({ message: "Conversation not found" });

    const otherUserId = conversation.participants
      .map(p => p._id.toString())
      .find(id => id !== req.user._id.toString());

    if (otherUserId && await isBlocked(req.user._id, otherUserId)) {
      return res.status(403).json({ message: "Conversation restricted." });
    }
    res.json(conversation);
  } catch (err) {
    console.error("GET CONVERSATION ERROR:", err);
    res.status(500).json({ message: "Failed to load conversation" });
  }
};

/* ---------- sending ---------- */
exports.sendMessage = async (req, res) => {
  try {
    const senderId = req.user._id;
    const body = req.body || {};
    const conversationId = body.conversationId ? String(body.conversationId).trim() : "";
    const text = typeof body.text === "string" ? body.text : "";
    const media = typeof body.media === "string" ? body.media : "";
    const type = body.type || "text";
    const voiceDuration = body.voiceDuration || "";
    const replyTo = body.replyTo;
    const allowedTypes = new Set(["text", "image", "video", "document", "voice", "gift"]);

    if (!conversationId) return res.status(400).json({ message: "conversationId required" });
    if (!mongoose.Types.ObjectId.isValid(conversationId)) {
      return res.status(400).json({ message: "Invalid conversation" });
    }
    if (!allowedTypes.has(type)) return res.status(400).json({ message: "Invalid message type" });
    if (!text.trim() && !media) return res.status(400).json({ message: "Empty message" });

    const conversation = await Conversation.findById(conversationId).populate("participants", "_id");
    if (!conversation) return res.status(404).json({ message: "Conversation not found" });

    const isParticipant = conversation.participants.some(
      (u) => u._id.toString() === senderId.toString()
    );
    if (!isParticipant) {
      return res.status(403).json({ message: "You are not a participant in this conversation" });
    }

    const recipient = conversation.participants.find(u => u._id.toString() !== senderId.toString());

    if (recipient && await isBlocked(senderId, recipient._id)) {
      return res.status(403).json({ message: "Message could not be sent." });
    }

    let message = await Message.create({
      conversation: conversationId,
      sender: senderId,
      text, media, type, voiceDuration,
      replyTo: replyTo || null
    });

    // post-save side effects (best-effort, never fail the request)
    try {
      const { handleMentions } = require("../utils/mentionHelper");
      if (text) await handleMentions(text, senderId, "message", message._id);
    } catch (e) { console.warn("mention scan failed:", e.message); }

    try { await logActivity(senderId, "message", message._id); } catch (_) {}

    message = await message.populate("sender", POPULATE_SENDER);
    if (message.replyTo) await message.populate("replyTo");

    const preview = text || (type === "image" ? "📷 Photo"
                          : type === "video"    ? "🎬 Video"
                          : type === "voice"    ? "🎙️ Voice message"
                          : type === "document" ? "📎 Document"
                          : type === "gift"     ? "🎁 Gift"
                          : "Message");

    await Conversation.findByIdAndUpdate(conversationId, {
      lastMessage: preview,
      lastMessageAt: new Date(),
      $pull: { archivedBy: { $in: conversation.participants.map(p => p._id) } }
    });

    // realtime
    emit(req, `conversation:${conversationId}`, "message:new", message);
    if (recipient) emit(req, `user:${recipient._id}`, "message:new", message);
    emit(req, `user:${senderId}`, "message:new", message);

    if (recipient) {
      try {
        await Notification.create({ recipient: recipient._id, sender: senderId, type: "message" });
        const sender = await User.findById(senderId);
        await sendPushNotification(recipient._id, {
          title: "New Message",
          body: `${sender.fullName} sent you a message 📩`,
          icon: sender.profilePicture || "/uploads/images/africa.png",
          data: { url: "/message.html" }
        });
      } catch (e) { console.warn("notify failed:", e.message); }
    }

    res.status(201).json({ message: "Message sent successfully", data: message });
  } catch (err) {
    console.error("SEND MESSAGE ERROR:", err);
    res.status(500).json({ message: err.message || "Failed to send message" });
  }
};

/* ---------- messages list ---------- */
exports.getMessages = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const page  = Math.max(parseInt(req.query.page  || "1", 10), 1);
    const limit = Math.min(parseInt(req.query.limit || "30", 10), 100);

    // honor per-user "clear chat" cutoff
    const conv = await Conversation.findById(conversationId).select("clearedBy");
    let cutoff = null;
    if (conv && Array.isArray(conv.clearedBy)) {
      const mine = conv.clearedBy.find(c => c.user && c.user.toString() === req.user._id.toString());
      if (mine) cutoff = mine.at;
    }

    const filter = { conversation: conversationId };
    if (cutoff) filter.createdAt = { $gt: cutoff };

    const total = await Message.countDocuments(filter);
    const messages = await Message.find(filter)
      .populate("sender", POPULATE_SENDER)
      .populate("replyTo")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.json({ messages: messages.reverse(), page, hasMore: page * limit < total });
  } catch (err) {
    console.error("GET MESSAGES ERROR:", err);
    res.status(500).json({ message: "Failed to load messages" });
  }
};

/* ---------- unread / read ---------- */
exports.getUnreadCount = async (req, res) => {
  try {
    const userId = req.user._id;
    const me = await User.findById(userId).select("blockedUsers");
    const whoBlockedMe = await User.find({ blockedUsers: userId }).select("_id");
    const hiddenUsers = [
      ...(me?.blockedUsers || []).map(String),
      ...whoBlockedMe.map(u => u._id.toString()),
    ];

    const conversations = await Conversation.find({
      $and: [
        { participants: userId },
        { participants: { $nin: hiddenUsers } }
      ]
    }).select("_id");

    const count = await Message.countDocuments({
      conversation: { $in: conversations.map(c => c._id) },
      sender: { $ne: userId },
      isRead: false
    });
    res.json({ count });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch unread count" });
  }
};

exports.markMessagesAsRead = async (req, res) => {
  try {
    const { conversationId } = req.params;
    await Message.updateMany(
      { conversation: conversationId, sender: { $ne: req.user._id }, isRead: false },
      { $set: { isRead: true } }
    );
    emit(req, `conversation:${conversationId}`, "message:read", {
      conversationId, by: req.user._id
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: "Failed to mark messages as read" });
  }
};

// Convenience used by frontend (`POST /api/messages/:userId/read`)
exports.markReadByUser = async (req, res) => {
  try {
    const userId  = req.user._id;
    const otherId = req.params.userId;
    const conv = await Conversation.findOne({
      participants: { $all: [userId, otherId], $size: 2 }
    });
    if (!conv) return res.json({ success: true });
    await Message.updateMany(
      { conversation: conv._id, sender: { $ne: userId }, isRead: false },
      { $set: { isRead: true } }
    );
    emit(req, `conversation:${conv._id}`, "message:read", { conversationId: conv._id, by: userId });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: "Failed" });
  }
};

/* ---------- archive / unarchive / clear ---------- */
exports.archiveConversation = async (req, res) => {
  try {
    await Conversation.updateOne({ _id: req.params.id }, { $addToSet: { archivedBy: req.user._id } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

exports.unarchiveConversation = async (req, res) => {
  try {
    await Conversation.updateOne({ _id: req.params.id }, { $pull: { archivedBy: req.user._id } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

exports.clearConversation = async (req, res) => {
  try {
    const id = req.params.id;
    await Conversation.updateOne(
      { _id: id, "clearedBy.user": { $ne: req.user._id } },
      { $push: { clearedBy: { user: req.user._id, at: new Date() } } }
    );
    await Conversation.updateOne(
      { _id: id, "clearedBy.user": req.user._id },
      { $set: { "clearedBy.$.at": new Date() } }
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

/* ---------- delete a single message ---------- */
exports.deleteMessage = async (req, res) => {
  try {
    const { forEveryone } = req.body || {};
    const msg = await Message.findById(req.params.msgId);
    if (!msg) return res.status(404).json({ message: "Not found" });

    if (msg.sender.toString() !== req.user._id.toString() && forEveryone) {
      return res.status(403).json({ message: "Only the sender can delete for everyone." });
    }

    if (forEveryone) {
      await Message.deleteOne({ _id: msg._id });
    } else {
      msg.text = "";
      msg.media = "";
      msg.type = "text";
      msg.deletedFor = msg.deletedFor || [];
      if (!msg.deletedFor.map(String).includes(req.user._id.toString())) {
        msg.deletedFor.push(req.user._id);
      }
      await msg.save();
    }

    const room = msg.group ? `group:${msg.group}` : `conversation:${msg.conversation}`;
    emit(req, room, "message:deleted", { _id: msg._id, forEveryone: !!forEveryone });
    res.json({ success: true });
  } catch (e) {
    console.error("DELETE MESSAGE ERROR:", e);
    res.status(500).json({ message: "Failed" });
  }
};

/* ---------- typing indicator (no DB write) ---------- */
exports.typing = async (req, res) => {
  try {
    const otherId = req.params.userId;
    const conv = await Conversation.findOne({
      participants: { $all: [req.user._id, otherId], $size: 2 }
    }).select("_id");
    if (conv) {
      emit(req, `user:${otherId}`, "typing:start", {
        conversationId: conv._id, from: req.user._id
      });
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

/* ---------- search messages ---------- */
exports.searchMessages = async (req, res) => {
  try {
    const q = (req.query.q || "").trim();
    if (!q) return res.json({ messages: [] });

    const myConvs = await Conversation.find({ participants: req.user._id }).select("_id");
    const myGroups = await Group.find({ members: req.user._id }).select("_id");

    const messages = await Message.find({
      $and: [
        { $or: [
          { conversation: { $in: myConvs.map(c => c._id) } },
          { group:        { $in: myGroups.map(g => g._id) } }
        ]},
        { text: { $regex: q, $options: "i" } }
      ]
    })
      .populate("sender", POPULATE_SENDER)
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({ messages });
  } catch (e) {
    res.status(500).json({ message: "Failed" });
  }
};
