const mongoose = require("mongoose");

const groupSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },

    description: {
      type: String,
      default: ""
    },

    profilePicture: {
      type: String,
      default: ""
    },

    // group creator (better naming than admin for scaling)
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    // group members
    members: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    inviteCode: {
      type: String,
      unique: true
    },

    // LAST MESSAGE SUPPORT (VERY IMPORTANT FOR CHAT LIST)
    lastMessage: {
      text: {
        type: String,
        default: ""
      },
      sender: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      },
      createdAt: {
        type: Date
      }
    },

    // ARCHIVE SUPPORT (matches frontend later)
    isArchived: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);

/**
 * Virtual field for frontend compatibility
 */
groupSchema.virtual("memberCount").get(function () {
  return this.members ? this.members.length : 0;
});

// ensure virtuals are included in JSON
groupSchema.set("toJSON", { virtuals: true });
groupSchema.set("toObject", { virtuals: true });

module.exports = mongoose.model("Group", groupSchema);
