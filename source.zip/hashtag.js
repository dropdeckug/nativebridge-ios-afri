// ══════════════════════════════════════════════
//  DARK MODE
// ══════════════════════════════════════════════
if (localStorage.getItem("afri_theme") === "dark") document.body.classList.add("dark");

const API_BASE = "https://afrisocial-backend.onrender.com";
const token = localStorage.getItem("token");

// Get hashtag from URL
const urlParams = new URLSearchParams(window.location.search);
const hashtag = urlParams.get('tag');

const hashtagTitle = document.getElementById("hashtagTitle");
const hashtagPosts = document.getElementById("hashtagPosts");
const feed = document.getElementById("feed");
const loader = document.getElementById("loader");
const errorDiv = document.getElementById("error");

let currentPage = 1;
let isLoading = false;
let hasMore = true;

if (!hashtag) {
  showError("No hashtag provided.");
} else {
  hashtagTitle.textContent = `#${hashtag}`;
  loadHashtagPosts(hashtag, 1);
}

async function loadHashtagPosts(tag, page) {
  if (isLoading || !hasMore) return;
  isLoading = true;
  if (page === 1) loader.classList.remove("hidden");

  try {
    const res = await fetch(
      `${API_BASE}/api/posts/hashtag/${tag}?page=${page}`,
      { headers: { "Authorization": `Bearer ${token}` } }
    );

    if (!res.ok) throw new Error("Failed to fetch");

    const data = await res.json();
    loader.classList.add("hidden");
    feed.classList.remove("hidden");

    const totalPosts = data.totalPosts || data.posts?.length || 0;
    if (page === 1) hashtagPosts.textContent = `${formatNumber(totalPosts)} posts`;

    renderPosts(data.posts || []);
    
    hasMore = data.hasMore !== false && (data.posts?.length > 0);
    currentPage = page;
    isLoading = false;
  } catch (err) {
    console.error(err);
    loader.classList.add("hidden");
    showError("Error loading posts");
    isLoading = false;
  }
}

// ══════════════
//  HELPERS
// ══════════════

function escapeHTML(str) {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function highlight(text) {
  if (!text) return "";
  const safeText = escapeHTML(text);
  // Make hashtags clickable
  return safeText.replace(/#(\w+)/g, 
    `<a href="/hashtag.html?tag=$1" class="hashtag-link">#$1</a>`
  );
}

function formatNumber(num) {
  if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
  if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
  if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
  return num;
}

//  RENDER POSTS 
function renderPosts(posts) {
  if (posts.length === 0 && currentPage === 1) {
    feed.innerHTML = `<div style="padding:40px;text-align:center;color:var(--text-muted)">No posts found for #${hashtag}</div>`;
    return;
  }

  const html = posts.map(item => {
    const postId = item.id;
    const authorPic = item.user?.profilePicture || '/uploads/images/africa.png';
    const authorName = item.user?.fullName || item.user?.username || "Unknown User";
    const text = item.text || item.caption || '';
    const highlightedText = highlight(text);
    
    // Check media array first
    const firstMedia = item.media?.[0];
    const mediaType = firstMedia?.type || item.type;
    
    // VIDEO: same layout as image post, caption first, with play button
    if (mediaType === "video" || item.type === "video") {
      const videoUrl = item.video || firstMedia?.url;
      const thumb = item.thumbnail || firstMedia?.thumbnail || '/uploads/images/video.png';
      return `
        <div class="post-card-img video-post" onclick="location.href='/vybze-player.html?id=${postId}'" data-video="${videoUrl}">
          <div class="post-head">
            <img src="${authorPic}" onerror="this.src='/uploads/images/africa.png'">
            <strong>${escapeHTML(authorName)}</strong>
          </div>
          
          ${text ? `<div class="post-caption">${highlightedText}</div>` : ''}
          
          <div class="post-media-wrapper">
            <img class="post-img" src="${thumb}" alt="${escapeHTML(item.title || text)}" onerror="this.style.display='none'">
            <div class="video-play-overlay">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="white">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>
          </div>
          
          <div class="post-actions">
            <button class="action-btn love-btn" onclick="event.stopPropagation()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
              </svg>
              <span class="count">${(item.likes || []).length}</span>
            </button>
            <button class="action-btn comment-btn" onclick="event.stopPropagation()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
              <span class="count">${item.commentCount || 0}</span>
            </button>
            <button class="action-btn star-btn" onclick="event.stopPropagation()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
              <span class="count">${(item.stars || []).length}</span>
            </button>
          </div>
        </div>`;
    }

    // IMAGE POST: caption now comes before image
    if (mediaType === "image" || item.image) {
      const postImg = firstMedia?.url || item.image;
      return `
        <div class="post-card-img" onclick="location.href='/view-post.html?id=${postId}'">
          <div class="post-head">
            <img src="${authorPic}" onerror="this.src='/uploads/images/africa.png'">
            <strong>${escapeHTML(authorName)}</strong>
          </div>
          
          ${text ? `<div class="post-caption">${highlightedText}</div>` : ''}
          
          <img class="post-img" src="${postImg}" alt="post" onerror="this.style.display='none'">
          
          <div class="post-actions">
            <button class="action-btn love-btn" onclick="event.stopPropagation()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
              </svg>
              <span class="count">${(item.likes || []).length}</span>
            </button>
            <button class="action-btn comment-btn" onclick="event.stopPropagation()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
              <span class="count">${item.commentCount || 0}</span>
            </button>
            <button class="action-btn star-btn" onclick="event.stopPropagation()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
              <span class="count">${(item.stars || []).length}</span>
            </button>
          </div>
        </div>`;
    }

    // TEXT ONLY POST
    return `
      <div class="post-card-img" onclick="location.href='/view-post.html?id=${postId}'">
        <div class="post-head">
          <img src="${authorPic}" onerror="this.src='/uploads/images/africa.png'">
          <strong>${escapeHTML(authorName)}</strong>
        </div>
        <div class="post-text">${highlightedText}</div>
        <div class="post-actions">
          <button class="action-btn love-btn" onclick="event.stopPropagation()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
            </svg>
            <span class="count">${(item.likes || []).length}</span>
          </button>
          <button class="action-btn comment-btn" onclick="event.stopPropagation()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            <span class="count">${item.commentCount || 0}</span>
          </button>
          <button class="action-btn star-btn" onclick="event.stopPropagation()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            <span class="count">${(item.stars || []).length}</span>
          </button>
        </div>
      </div>`;
  }).join("");

  if (currentPage === 1) {
    feed.innerHTML = html;
  } else {
    feed.innerHTML += html;
  }
}
// scroll
window.addEventListener("scroll", () => {
  if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 500) {
    if (!isLoading && hasMore && hashtag) {
      loadHashtagPosts(hashtag, currentPage + 1);
    }
  }
});



function showError(msg) {
  errorDiv.textContent = msg;
  errorDiv.classList.remove("hidden");
}

document.getElementById("shareBtn").addEventListener("click", () => {
  const url = window.location.href;
  if (navigator.share) {
    navigator.share({ title: `#${hashtag}`, url });
  } else {
    navigator.clipboard.writeText(url);
    alert("Link copied!");
  }
});
